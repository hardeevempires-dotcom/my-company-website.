import express from 'express';
import { createServer as createViteServer } from 'vite';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import {
  SERVICES_CATALOG,
  PORTFOLIO_PROJECTS,
  DEFAULT_SITE_SETTINGS,
} from './src/data/catalog.js';
import type { EnquirySubmission, ProjectItem, ServiceItem, SiteSettings } from './src/types/index.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.join(__dirname, 'data');
const STORE_PATH = path.join(DATA_DIR, 'store.json');

interface PersistentStore {
  enquiries: EnquirySubmission[];
  projects: ProjectItem[];
  services: ServiceItem[];
  settings: SiteSettings;
}

function loadStore(): PersistentStore {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (fs.existsSync(STORE_PATH)) {
      const raw = fs.readFileSync(STORE_PATH, 'utf-8');
      const parsed = JSON.parse(raw) as Partial<PersistentStore>;
      return {
        enquiries: Array.isArray(parsed.enquiries) ? parsed.enquiries : getInitialEnquiries(),
        projects: Array.isArray(parsed.projects) && parsed.projects.length > 0 ? parsed.projects : PORTFOLIO_PROJECTS,
        services: Array.isArray(parsed.services) && parsed.services.length > 0 ? parsed.services : SERVICES_CATALOG,
        settings: parsed.settings ? { ...DEFAULT_SITE_SETTINGS, ...parsed.settings } : {
          ...DEFAULT_SITE_SETTINGS,
          whatsappNumber: process.env.VITE_WHATSAPP_NUMBER || DEFAULT_SITE_SETTINGS.whatsappNumber,
          contactEmail: process.env.VITE_COMPANY_EMAIL || DEFAULT_SITE_SETTINGS.contactEmail,
        },
      };
    }
  } catch (err) {
    console.error('Error loading store.json, initializing defaults:', err);
  }

  const initialStore: PersistentStore = {
    enquiries: getInitialEnquiries(),
    projects: PORTFOLIO_PROJECTS,
    services: SERVICES_CATALOG,
    settings: {
      ...DEFAULT_SITE_SETTINGS,
      whatsappNumber: process.env.VITE_WHATSAPP_NUMBER || DEFAULT_SITE_SETTINGS.whatsappNumber,
      contactEmail: process.env.VITE_COMPANY_EMAIL || DEFAULT_SITE_SETTINGS.contactEmail,
    },
  };
  saveStore(initialStore);
  return initialStore;
}

function getInitialEnquiries(): EnquirySubmission[] {
  return [
    {
      id: 'sample-demo-enquiry',
      referenceCode: 'BA-ENQ-DEMO',
      fullName: 'Sample Client Demonstration (Test Record)',
      email: 'demo-client@example.com',
      phone: '+60 12-000 0000',
      companyName: 'Sample Field Operations Sdn Bhd (Demonstration)',
      serviceRequired: 'Business Management Systems',
      projectDescription:
        'Sample demonstration enquiry showing how BUILD AURA tracks incoming project requests, prepares technical quotations in RM, and updates project status.',
      estimatedBudgetRM: 'RM 25,000 – RM 50,000',
      preferredTimeline: '2 – 3 Months',
      attachmentName: 'service-workflow-brief-sample.pdf',
      attachmentSize: 245760,
      status: 'Quotation Prepared',
      adminNotes:
        'Sample demonstration record: Technical architecture and Phase 1 milestone breakdown prepared for review.',
      createdAt: new Date().toISOString(),
    },
  ];
}

function saveStore(store: PersistentStore): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(STORE_PATH, JSON.stringify(store, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to persist store.json:', err);
  }
}

// Simple in-memory IP rate limit map for enquiry spam protection
const submissionTimestamps = new Map<string, number[]>();

function isRateLimited(ip: string): boolean {
  const now = Date.now();
  const windowMs = 10 * 60 * 1000; // 10 minutes
  const maxRequests = 8;
  const recent = (submissionTimestamps.get(ip) || []).filter((t) => now - t < windowMs);
  if (recent.length >= maxRequests) {
    return true;
  }
  recent.push(now);
  submissionTimestamps.set(ip, recent);
  return false;
}

function requireAdminAuth(req: express.Request, res: express.Response, next: express.NextFunction) {
  const expectedPasscode = process.env.ADMIN_PASSCODE || 'buildaura-admin-2026';
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Unauthorized: Missing administrator token.' });
    return;
  }
  const token = authHeader.slice('Bearer '.length).trim();
  if (token !== expectedPasscode) {
    res.status(403).json({ error: 'Forbidden: Invalid administrator passcode.' });
    return;
  }
  next();
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '2mb' }));

  // Public bootstrap endpoint: returns current catalog & public site settings
  app.get('/api/bootstrap', (_req, res) => {
    const store = loadStore();
    res.json({
      services: store.services,
      projects: store.projects,
      settings: store.settings,
    });
  });

  // Public Enquiry Submission Endpoint with strict server validation & spam protection
  app.post('/api/enquiries', async (req, res) => {
    try {
      const clientIp = req.ip || req.socket.remoteAddress || 'unknown';
      if (isRateLimited(clientIp)) {
        res.status(429).json({
          error: 'Too many enquiries submitted recently. Please wait a few minutes before trying again.',
        });
        return;
      }

      const {
        fullName,
        email,
        phone,
        companyName,
        serviceRequired,
        projectDescription,
        estimatedBudgetRM,
        preferredTimeline,
        attachmentName,
        attachmentSize,
        websiteHoneypot, // hidden spam trap field
      } = req.body || {};

      // Spam protection check: if honeypot is filled, reject silently/explicitly
      if (websiteHoneypot && String(websiteHoneypot).trim().length > 0) {
        res.status(400).json({ error: 'Spam verification failed.' });
        return;
      }

      // Server-side validation
      const errors: Record<string, string> = {};
      if (!fullName || String(fullName).trim().length < 2) {
        errors.fullName = 'Please enter your full name (at least 2 characters).';
      }
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!email || !emailRegex.test(String(email).trim())) {
        errors.email = 'Please provide a valid email address.';
      }
      const phoneClean = String(phone || '').trim();
      if (!phoneClean || phoneClean.length < 7 || !/^[+\d\s()-]{7,24}$/.test(phoneClean)) {
        errors.phone = 'Please provide a valid phone or WhatsApp number.';
      }
      if (!serviceRequired || String(serviceRequired).trim().length === 0) {
        errors.serviceRequired = 'Please select the primary service required.';
      }
      if (!projectDescription || String(projectDescription).trim().length < 20) {
        errors.projectDescription = 'Please describe your project requirements (at least 20 characters).';
      }
      if (!estimatedBudgetRM || String(estimatedBudgetRM).trim().length === 0) {
        errors.estimatedBudgetRM = 'Please select an estimated budget range in RM.';
      }
      if (!preferredTimeline || String(preferredTimeline).trim().length === 0) {
        errors.preferredTimeline = 'Please select your preferred project timeline.';
      }

      if (Object.keys(errors).length > 0) {
        res.status(400).json({
          error: 'Please correct the highlighted fields before submitting.',
          fieldErrors: errors,
        });
        return;
      }

      const store = loadStore();
      const randomSuffix = Math.floor(1000 + Math.random() * 9000);
      const datePart = new Date().toISOString().slice(2, 10).replace(/-/g, '');
      const referenceCode = `BA-${datePart}-${randomSuffix}`;

      const newEnquiry: EnquirySubmission = {
        id: `enq_${Date.now()}_${randomSuffix}`,
        referenceCode,
        fullName: String(fullName).trim(),
        email: String(email).trim(),
        phone: phoneClean,
        companyName: String(companyName || '').trim() || 'Individual / Startup',
        serviceRequired: String(serviceRequired).trim(),
        projectDescription: String(projectDescription).trim(),
        estimatedBudgetRM: String(estimatedBudgetRM).trim(),
        preferredTimeline: String(preferredTimeline).trim(),
        attachmentName: attachmentName ? String(attachmentName).trim() : undefined,
        attachmentSize: typeof attachmentSize === 'number' ? attachmentSize : undefined,
        status: 'Received',
        adminNotes: 'Enquiry logged in BUILD AURA backend database. Pending initial engineering review.',
        createdAt: new Date().toISOString(),
      };

      store.enquiries.unshift(newEnquiry);
      saveStore(store);

      // Optional real webhook notification forwarding if ENQUIRY_WEBHOOK_URL is configured
      const webhookUrl = process.env.ENQUIRY_WEBHOOK_URL;
      let webhookNotified = false;
      if (webhookUrl && webhookUrl.startsWith('http')) {
        try {
          const webhookRes = await fetch(webhookUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              source: 'BUILD AURA Enquiry Engine',
              enquiry: newEnquiry,
            }),
          });
          webhookNotified = webhookRes.ok;
        } catch (webhookErr) {
          console.error('Optional enquiry webhook notification failed:', webhookErr);
        }
      }

      res.status(201).json({
        success: true,
        message: 'Your project enquiry has been securely recorded in the BUILD AURA backend.',
        referenceCode: newEnquiry.referenceCode,
        submittedAt: newEnquiry.createdAt,
        webhookNotified,
        enquiry: {
          referenceCode: newEnquiry.referenceCode,
          fullName: newEnquiry.fullName,
          serviceRequired: newEnquiry.serviceRequired,
          estimatedBudgetRM: newEnquiry.estimatedBudgetRM,
          preferredTimeline: newEnquiry.preferredTimeline,
          status: newEnquiry.status,
          createdAt: newEnquiry.createdAt,
        },
      });
    } catch (error) {
      console.error('Failed to process enquiry:', error);
      res.status(500).json({
        error: 'An unexpected server error occurred while saving your enquiry. Please try again.',
      });
    }
  });

  // Public Enquiry & Quotation Status Lookup by Reference Code
  app.get('/api/enquiries/lookup/:referenceCode', (req, res) => {
    const code = String(req.params.referenceCode || '').trim().toUpperCase();
    if (!code) {
      res.status(400).json({ error: 'Please provide a valid enquiry reference code.' });
      return;
    }
    const store = loadStore();
    const match = store.enquiries.find((e) => e.referenceCode.toUpperCase() === code);
    if (!match) {
      res.status(404).json({
        error: `No enquiry found matching reference code "${code}". Try "BA-ENQ-DEMO" to view a sample tracked record.`,
      });
      return;
    }
    // Return safe status summary without exposing private contact details of others
    res.json({
      referenceCode: match.referenceCode,
      companyName: match.companyName,
      serviceRequired: match.serviceRequired,
      estimatedBudgetRM: match.estimatedBudgetRM,
      preferredTimeline: match.preferredTimeline,
      status: match.status,
      adminNotes: match.adminNotes,
      createdAt: match.createdAt,
    });
  });

  // Admin Authentication Verification
  app.post('/api/admin/verify', requireAdminAuth, (_req, res) => {
    const store = loadStore();
    res.json({
      authenticated: true,
      enquiries: store.enquiries,
      projects: store.projects,
      services: store.services,
      settings: store.settings,
    });
  });

  // Admin: Update Enquiry Status or Notes
  app.patch('/api/admin/enquiries/:id', requireAdminAuth, (req, res) => {
    const { id } = req.params;
    const { status, adminNotes } = req.body || {};
    const store = loadStore();
    const index = store.enquiries.findIndex((e) => e.id === id);
    if (index === -1) {
      res.status(404).json({ error: 'Enquiry not found.' });
      return;
    }
    if (status) {
      store.enquiries[index].status = status;
    }
    if (typeof adminNotes === 'string') {
      store.enquiries[index].adminNotes = adminNotes.trim();
    }
    saveStore(store);
    res.json({ success: true, enquiry: store.enquiries[index] });
  });

  // Admin: Delete Enquiry
  app.delete('/api/admin/enquiries/:id', requireAdminAuth, (req, res) => {
    const { id } = req.params;
    const store = loadStore();
    store.enquiries = store.enquiries.filter((e) => e.id !== id);
    saveStore(store);
    res.json({ success: true });
  });

  // Admin: Update Site Settings (WhatsApp number, contact email, availability)
  app.put('/api/admin/settings', requireAdminAuth, (req, res) => {
    const store = loadStore();
    const { whatsappNumber, contactEmail, businessHours, locationNote, acceptingNewProjects } = req.body || {};
    store.settings = {
      ...store.settings,
      whatsappNumber: typeof whatsappNumber === 'string' ? whatsappNumber.trim() : store.settings.whatsappNumber,
      contactEmail: typeof contactEmail === 'string' ? contactEmail.trim() : store.settings.contactEmail,
      businessHours: typeof businessHours === 'string' ? businessHours.trim() : store.settings.businessHours,
      locationNote: typeof locationNote === 'string' ? locationNote.trim() : store.settings.locationNote,
      acceptingNewProjects:
        typeof acceptingNewProjects === 'boolean' ? acceptingNewProjects : store.settings.acceptingNewProjects,
    };
    saveStore(store);
    res.json({ success: true, settings: store.settings });
  });

  // Admin: Add or Update Portfolio Project
  app.post('/api/admin/projects', requireAdminAuth, (req, res) => {
    const project = req.body as ProjectItem;
    if (!project || !project.title || !project.slug) {
      res.status(400).json({ error: 'Project title and slug are required.' });
      return;
    }
    const store = loadStore();
    const existingIdx = store.projects.findIndex((p) => p.id === project.id || p.slug === project.slug);
    if (existingIdx >= 0) {
      store.projects[existingIdx] = project;
    } else {
      store.projects.push(project);
    }
    saveStore(store);
    res.json({ success: true, projects: store.projects });
  });

  // Mount Vite middleware in development or static dist in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom',
    });

    // Dedicated standalone admin website routing in development
    app.get(['/admin', '/admin/*', '/admin.html'], async (req, res, next) => {
      try {
        const url = req.originalUrl;
        let template = fs.readFileSync(path.join(__dirname, 'admin.html'), 'utf-8');
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e) {
        next(e);
      }
    });

    app.use(vite.middlewares);

    app.get('*', async (req, res, next) => {
      try {
        const url = req.originalUrl;
        let template = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf-8');
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e) {
        next(e);
      }
    });
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    // Dedicated standalone admin website routing in production
    app.get(['/admin', '/admin/*', '/admin.html'], (_req, res) => {
      res.sendFile(path.join(distPath, 'admin.html'));
    });
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`BUILD AURA server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
