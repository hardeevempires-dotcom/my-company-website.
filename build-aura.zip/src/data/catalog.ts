import { ServiceItem, ProjectItem, ProcessPhase, SiteSettings } from '../types';

export const HERO_IMAGE_PATH = '/src/assets/images/hero_software_platform_1793148713914.jpg';
export const SERVICEFLOW_IMAGE_PATH = '/src/assets/images/project_serviceflow_dashboard_1793148714930.jpg';
export const COMMERCE_IMAGE_PATH = '/src/assets/images/project_aura_commerce_1793148715417.jpg';
export const AI_OPS_IMAGE_PATH = '/src/assets/images/project_neural_ops_ai_1793148715381.jpg';

export const DEFAULT_SITE_SETTINGS: SiteSettings = {
  companyName: 'BUILD AURA',
  tagline: 'Build Beyond Expectations.',
  whatsappNumber: '',
  contactEmail: 'enquiries@buildaura.tech',
  businessHours: 'Monday – Friday, 9:00 AM – 6:00 PM (MYT / GMT+8)',
  locationNote: 'Remote-First Engineering Studio · Serving Malaysia & Global Clients',
  acceptingNewProjects: true,
};

export const SERVICES_CATALOG: ServiceItem[] = [
  {
    id: 'website-design-dev',
    index: '01',
    title: 'Website Design and Development',
    category: 'Web Engineering',
    shortDescription:
      'High-performance corporate websites, product landing pages, and custom web applications engineered for speed, accessibility, and conversion.',
    fullDescription:
      'We architect bespoke websites from the ground up using modern component frameworks, semantic HTML, and responsive layouts. Every website is built to load rapidly, communicate your brand authority clearly, and turn visitors into qualified enquiries.',
    iconName: 'Globe',
    benefits: [
      'Sub-second page transitions with responsive layouts across desktop, tablet, and mobile viewports',
      'Clean semantic structure with built-in technical SEO, Open Graph metadata, and schema markup',
      'Maintainable content architecture that grows alongside your business offerings',
    ],
    deliverables: ['Responsive Web Application', 'CMS / Admin Content Controls', 'SEO & Analytics Readiness'],
    typicalTimeline: '3 – 6 Weeks',
    startingEstimateRM: 'RM 4,500 – RM 15,000',
  },
  {
    id: 'ecommerce-dev',
    index: '02',
    title: 'E-commerce Website Development',
    category: 'Digital Commerce',
    shortDescription:
      'Custom online storefronts and B2B ordering portals with real-time inventory synchronization, Malaysian payment gateways, and order tracking.',
    fullDescription:
      'Whether launching a direct-to-consumer brand or a wholesale distributor portal, we build resilient commerce platforms featuring streamlined checkout flows, multi-tier pricing, FPX/card/e-wallet payment readiness, and automated stock management.',
    iconName: 'ShoppingBag',
    benefits: [
      'Frictionless product filtering, cart management, and mobile-optimized checkout flows',
      'Integration readiness for FPX, Stripe, Billplz, SenangPay, and regional logistics couriers',
      'Unified product catalog, SKU stock alerts, and customer purchase history dashboards',
    ],
    deliverables: ['Custom Storefront', 'Order & Inventory Management Console', 'Payment & Courier Integration'],
    typicalTimeline: '5 – 8 Weeks',
    startingEstimateRM: 'RM 8,000 – RM 25,000',
  },
  {
    id: 'mobile-app-dev',
    index: '03',
    title: 'Mobile Application Development for Android and iOS',
    category: 'Mobile Platforms',
    shortDescription:
      'Cross-platform and native-grade mobile applications for iOS and Android designed for field teams, consumers, and on-the-go operations.',
    fullDescription:
      'We develop responsive, tactile mobile applications that work reliably across Android and iOS devices. From customer booking apps to field technician companions with offline caching and push notifications, our mobile builds prioritize usability and battery-conscious performance.',
    iconName: 'Smartphone',
    benefits: [
      'Unified codebase deployment to both Apple App Store and Google Play Store',
      'Support for biometric sign-in, camera barcode/QR scanning, geolocation, and push alerts',
      'Resilient API synchronization for users operating in variable network conditions',
    ],
    deliverables: ['iOS & Android Builds', 'Secure REST / GraphQL Backend API', 'App Store Submission Support'],
    typicalTimeline: '8 – 14 Weeks',
    startingEstimateRM: 'RM 18,000 – RM 45,000',
  },
  {
    id: 'custom-software-dev',
    index: '04',
    title: 'Custom Software Development',
    category: 'Bespoke Engineering',
    shortDescription:
      'Tailor-made software platforms engineered around your exact operational rules rather than forcing your team into rigid off-the-shelf templates.',
    fullDescription:
      'When commercial SaaS tools cannot accommodate your domain workflows, pricing models, or compliance requirements, we engineer dedicated software systems tailored to your organization—complete with role-based access control and audit trails.',
    iconName: 'Code2',
    benefits: [
      'Zero per-seat SaaS licensing bloat—own the workflow logic tailored to your business',
      'Granular role-based permissions for staff, supervisors, partners, and external clients',
      'Modular codebase designed for long-term maintainability and feature expansion',
    ],
    deliverables: ['Custom Web/Desktop Application', 'Technical Architecture Blueprint', 'Automated Test Suite'],
    typicalTimeline: '8 – 16 Weeks',
    startingEstimateRM: 'RM 20,000 – RM 65,000+',
  },
  {
    id: 'business-management-systems',
    index: '05',
    title: 'Business Management Systems',
    category: 'Enterprise Operations',
    shortDescription:
      'Centralized operational platforms connecting customer requests, quotations, job dispatch, inventory, invoicing, and executive reporting.',
    fullDescription:
      'Eliminate disconnected spreadsheets and WhatsApp threads. We build unified business management systems—exemplified by our flagship ServiceFlow architecture—that give leadership real-time visibility from initial customer enquiry through final invoice settlement.',
    iconName: 'Layers',
    benefits: [
      'End-to-end traceability from customer request and quotation approval to job completion',
      'Automated invoice generation, payment tracking, and spare-parts inventory deductions',
      'Real-time operational metrics and exportable financial summaries for management',
    ],
    deliverables: ['Operations Portal', 'Quotation & Invoicing Engine', 'Role-Based Staff Dashboards'],
    typicalTimeline: '8 – 16 Weeks',
    startingEstimateRM: 'RM 22,000 – RM 60,000',
  },
  {
    id: 'ai-chatbots-applications',
    index: '06',
    title: 'AI Chatbots and AI-powered Applications',
    category: 'Applied AI Solutions',
    shortDescription:
      'Practical, grounded AI assistants, document intelligence tools, and automated triage systems integrated directly into your business data.',
    fullDescription:
      'We implement high-utility AI applications that solve measurable operational bottlenecks: intelligent customer support triage grounded in your company knowledge base, automated quotation drafting, and structured data extraction from PDFs and invoices.',
    iconName: 'Cpu',
    benefits: [
      'Retrieval-augmented responses grounded strictly in your verified documentation and policies',
      'Automated extraction of line items from purchase orders, receipts, and technical briefs',
      'Seamless human-in-the-loop handoff so complex customer cases reach the right specialist',
    ],
    deliverables: ['Custom AI Service Layer', 'Knowledge Ingestion Pipeline', 'Usage & Safety Controls'],
    typicalTimeline: '4 – 8 Weeks',
    startingEstimateRM: 'RM 9,500 – RM 28,000',
  },
  {
    id: 'workflow-automation',
    index: '07',
    title: 'Workflow Automation',
    category: 'Process Efficiency',
    shortDescription:
      'Automated pipelines that eliminate repetitive manual data entry across your CRM, accounting software, email, and operational databases.',
    fullDescription:
      'Manual copy-pasting between forms, spreadsheets, and accounting tools introduces costly human error. We build deterministic workflow automations, scheduled jobs, and webhook triggers that keep your systems synchronized automatically.',
    iconName: 'Workflow',
    benefits: [
      'Drastic reduction in manual administrative hours spent on repetitive status updates',
      'Instant automated notifications via email, WhatsApp gateways, or internal dashboards',
      'Error logging and retry mechanisms so critical business events are never dropped',
    ],
    deliverables: ['Automated Event Pipelines', 'Webhook & Cron Orchestration', 'Execution Audit Logs'],
    typicalTimeline: '2 – 5 Weeks',
    startingEstimateRM: 'RM 5,000 – RM 16,000',
  },
  {
    id: 'ui-ux-design',
    index: '08',
    title: 'UI/UX Design',
    category: 'Product Design',
    shortDescription:
      'User research, interactive wireframes, high-contrast interface systems, and clickable prototypes crafted for clarity and ease of use.',
    fullDescription:
      'Great software requires intuitive interaction design. We translate complex multi-step business logic into clean, accessible interfaces—reducing staff training time and increasing customer self-service completion rates.',
    iconName: 'Layout',
    benefits: [
      'Interactive prototypes that let stakeholders test and validate workflows before coding begins',
      'Consistent design token systems covering typography, spacing, contrast, and states',
      'Accessibility-first mindset ensuring WCAG AA legibility and keyboard navigation',
    ],
    deliverables: ['User Journey Maps', 'Design System & Component Library', 'Interactive Prototypes'],
    typicalTimeline: '2 – 4 Weeks',
    startingEstimateRM: 'RM 4,000 – RM 12,000',
  },
  {
    id: 'database-backend-dev',
    index: '09',
    title: 'Database Design and Backend Development',
    category: 'Core Infrastructure',
    shortDescription:
      'Normalized relational schemas, high-throughput backend services, secure authentication, and data integrity enforcement.',
    fullDescription:
      'Your application is only as reliable as its underlying data model. We architect PostgreSQL, Cloud SQL, and document databases with strict schema validation, indexing strategies, role-based access rules, and automated backup policies.',
    iconName: 'Database',
    benefits: [
      'Clean relational data modeling that prevents duplicate records and reporting discrepancies',
      'Server-side authorization and encrypted credential management for sensitive records',
      'Optimized query performance designed to scale smoothly as transaction volume grows',
    ],
    deliverables: ['Database Schema & Migrations', 'Secure Backend Service Layer', 'Data Backup Strategy'],
    typicalTimeline: '3 – 7 Weeks',
    startingEstimateRM: 'RM 6,500 – RM 20,000',
  },
  {
    id: 'api-system-integration',
    index: '10',
    title: 'API Development and System Integration',
    category: 'Connectivity',
    shortDescription:
      'Secure RESTful APIs, webhook consumers, and third-party integrations connecting ERPs, payment gateways, and external partner systems.',
    fullDescription:
      'We build well-documented APIs and middleware bridges that allow disparate software platforms to communicate securely—whether integrating accounting platforms, logistics providers, SMS/WhatsApp gateways, or legacy databases.',
    iconName: 'Network',
    benefits: [
      'Strict request validation, rate limiting, and token-based authentication',
      'Reliable synchronization between modern web portals and existing enterprise software',
      'Clear OpenAPI / Swagger documentation for internal and partner engineering teams',
    ],
    deliverables: ['Versioned API Endpoints', 'Integration Middleware', 'API Documentation'],
    typicalTimeline: '3 – 6 Weeks',
    startingEstimateRM: 'RM 6,000 – RM 18,000',
  },
  {
    id: 'cloud-deployment-hosting',
    index: '11',
    title: 'Cloud Deployment and Hosting Setup',
    category: 'Cloud & DevOps',
    shortDescription:
      'Production cloud provisioning, containerized deployments, SSL security, custom domain routing, and automated CI/CD pipelines.',
    fullDescription:
      'We take the guesswork out of launching and hosting your digital products. From Google Cloud Run and AWS to managed database clusters and CDN caching, we configure secure, cost-effective cloud environments with zero-downtime deployment pipelines.',
    iconName: 'Cloud',
    benefits: [
      'Automated build and deployment pipelines triggered directly from version control',
      'HTTPS/TLS encryption, environment secret isolation, and firewall hardening',
      'Right-sized cloud architecture that scales with traffic while keeping monthly costs predictable',
    ],
    deliverables: ['Production Cloud Environment', 'CI/CD Deployment Pipeline', 'SSL & Domain Configuration'],
    typicalTimeline: '1 – 3 Weeks',
    startingEstimateRM: 'RM 3,000 – RM 10,000',
  },
  {
    id: 'maintenance-performance-seo',
    index: '12',
    title: 'Website Maintenance, Performance Optimisation, and SEO',
    category: 'Ongoing Reliability',
    shortDescription:
      'Continuous security patching, Core Web Vitals speed tuning, technical SEO audits, and proactive uptime care for existing platforms.',
    fullDescription:
      'Software requires continuous care after launch. We provide structured maintenance retainers and performance refactoring to eliminate slow database queries, reduce bundle sizes, improve search engine rankings, and keep dependencies secure.',
    iconName: 'Gauge',
    benefits: [
      'Measurable improvements in page load speed, Core Web Vitals, and mobile responsiveness',
      'Regular dependency updates, security vulnerability audits, and scheduled backups',
      'Dedicated engineering support for feature enhancements and content updates',
    ],
    deliverables: ['Performance & SEO Audit Report', 'Core Web Vitals Optimization', 'Scheduled Maintenance Care'],
    typicalTimeline: 'Ongoing / 2 – 4 Weeks Audit',
    startingEstimateRM: 'RM 1,200 / mo or RM 3,500 Audit',
  },
];

export const PORTFOLIO_PROJECTS: ProjectItem[] = [
  {
    id: 'serviceflow-system',
    slug: 'serviceflow',
    title: 'ServiceFlow',
    subtitle: 'End-to-End Field Service & Operations Management System',
    category: 'Business Systems',
    isFlagship: true,
    isSampleConcept: false,
    status: 'Active Production Architecture',
    overview:
      'ServiceFlow is BUILD AURA’s flagship service-management platform engineered to unify the complete lifecycle of technical service operations—connecting customer service requests, itemised quotations, job scheduling, technician assignments, invoicing, payment tracking, spare-parts inventory, and executive business insights in one cohesive system.',
    problemSolved:
      'Service-oriented businesses frequently suffer from operational fragmentation: customer enquiries arrive via phone or chat, quotations are drafted in standalone spreadsheets, technician schedules are coordinated verbally, and invoices are delayed because job completion notes and parts usage are not linked. This results in missed follow-ups, billing leakage, inventory shortages, and zero real-time visibility for management.',
    proposedSolution:
      'ServiceFlow replaces disconnected tools with a single state-driven workflow engine. When a customer request is logged, ServiceFlow generates an itemised quotation for digital approval, converts approved quotes directly into assignable technician jobs, deducts consumed inventory automatically, issues the final invoice upon job sign-off, and updates real-time financial and operational reports.',
    features: [
      'Customer Request Intake & Triage: Log service tickets with asset details, priority levels, and site location history.',
      'Dynamic Quotation Builder: Create multi-line quotations in RM with revision history and one-click conversion to active jobs.',
      'Job Dispatch & Technician Assignment: Assign field technicians by skill set, availability, and route schedule with live status progression.',
      'Invoicing & Payment Ledger: Generate invoices directly from completed job sheets and track partial, pending, or settled payments.',
      'Inventory & Spare Parts Control: Track warehouse and van stock levels, serial numbers, and low-stock reorder thresholds.',
      'Operational Reports & Business Insights: Monitor quotation conversion rates, first-time fix rates, technician utilization, and monthly revenue.',
    ],
    modules: [
      {
        name: '01. Requests & Quotations',
        summary: 'Structured intake from initial customer inquiry to formal quotation sign-off.',
        capabilities: [
          'Customer profile & equipment history lookup',
          'Itemised labour and parts quotation generator (RM)',
          'Approval status tracking (Draft, Sent, Approved, Revised)',
        ],
      },
      {
        name: '02. Jobs & Technician Dispatch',
        summary: 'Real-time scheduling, technician assignment, and field checklists.',
        capabilities: [
          'Conflict-free technician calendar & workload view',
          'Digital job sheets with before/after photo documentation',
          'Customer digital sign-off upon service completion',
        ],
      },
      {
        name: '03. Invoices, Payments & Inventory',
        summary: 'Automated billing reconciliation and spare-parts stock reservation.',
        capabilities: [
          'One-click quotation-to-invoice conversion',
          'Automatic stock deduction when parts are used on a job',
          'Aging receivables and payment settlement ledger',
        ],
      },
      {
        name: '04. Analytics & Executive Insights',
        summary: 'Decision-ready KPIs across revenue, SLA compliance, and stock turnover.',
        capabilities: [
          'Monthly revenue vs. operational cost breakdown',
          'Technician turnaround time & SLA adherence metrics',
          'Exportable CSV/PDF management statements',
        ],
      },
    ],
    technologies: ['React', 'TypeScript', 'Tailwind CSS', 'Node.js', 'PostgreSQL', 'REST API'],
    imageUrl: SERVICEFLOW_IMAGE_PATH,
    secondaryImageUrl: HERO_IMAGE_PATH,
    developmentProcess: [
      {
        phase: '01. Domain Workflow Mapping',
        detail:
          'Mapped the exact state transitions between Customer Request → Quotation → Work Order → Inventory Allocation → Invoice → Payment Receipt.',
      },
      {
        phase: '02. Relational Schema & State Integrity',
        detail:
          'Designed strict foreign-key schemas ensuring every invoice traces back to an approved quotation and verified technician job sheet.',
      },
      {
        phase: '03. High-Contrast Operational UI',
        detail:
          'Built scannable dispatch boards, tabular financial views, and mobile-responsive technician job cards for rapid field updates.',
      },
      {
        phase: '04. Reporting & Audit Verification',
        detail:
          'Implemented real-time aggregation pipelines for revenue tracking, outstanding receivables, and parts consumption analytics.',
      },
    ],
    architectureHighlights: [
      'Role-based access control separating Dispatchers, Field Technicians, Finance Officers, and Administrators',
      'Audit trail recording every status transition and quotation revision with timestamps',
      'Modular service layer ready for WhatsApp customer notifications and accounting exports',
    ],
  },
  {
    id: 'aura-b2b-commerce',
    slug: 'aura-commerce-hub',
    title: 'AuraTrade B2B Commerce & Inventory Portal',
    subtitle: 'Sample Concept Architecture — Wholesale Ordering & Fulfillment Platform',
    category: 'Websites',
    isFlagship: false,
    isSampleConcept: true,
    status: 'Sample Reference Architecture',
    overview:
      'A reference B2B e-commerce and distributor ordering web platform designed by BUILD AURA to demonstrate how wholesale suppliers can digitize bulk catalog ordering, tiered trade pricing, and multi-warehouse stock visibility.',
    problemSolved:
      'Wholesale distributors often process repeat trade orders manually via PDF price lists and messaging apps, resulting in pricing calculation errors and stock overselling.',
    proposedSolution:
      'An authenticated B2B web portal with account-specific pricing tiers, live SKU stock counters, quick bulk-order tables, and automated pro-forma invoice generation.',
    features: [
      'Tiered wholesale pricing rules based on distributor account classification',
      'Rapid SKU search and CSV bulk cart upload for repeat commercial buyers',
      'Real-time warehouse stock allocation and fulfillment step tracking',
      'Downloadable PDF tax invoices and account statement history',
    ],
    technologies: ['React', 'TypeScript', 'Tailwind CSS', 'Express API', 'PostgreSQL'],
    imageUrl: COMMERCE_IMAGE_PATH,
    developmentProcess: [
      {
        phase: '01. Catalog & Pricing Architecture',
        detail: 'Structured multi-tier SKU pricing schemas and bulk quantity break rules.',
      },
      {
        phase: '02. Fast-Order UX Prototyping',
        detail: 'Designed keyboard-friendly tabular ordering interfaces for high-volume buyers.',
      },
      {
        phase: '03. Fulfillment Pipeline Integration',
        detail: 'Connected order placement directly to warehouse pick-pack-ship status stages.',
      },
    ],
    architectureHighlights: [
      'Sub-second catalog filtering across thousands of technical SKUs',
      'Responsive layout supporting both desktop procurement teams and mobile sales reps',
    ],
  },
  {
    id: 'cognitive-doc-ops',
    slug: 'cognitive-workflow-hub',
    title: 'AuraFlow Document & Triage Automation',
    subtitle: 'Sample Concept Architecture — AI-Assisted Operations & Document Pipeline',
    category: 'AI Solutions',
    isFlagship: false,
    isSampleConcept: true,
    status: 'Sample Reference Architecture',
    overview:
      'A reference AI workflow architecture demonstrating how BUILD AURA integrates structured document extraction, rule validation, and intelligent support routing into internal enterprise operations.',
    problemSolved:
      'Operations teams spend hours manually transcribing line items from vendor purchase orders, delivery orders, and technical enquiry emails into internal databases.',
    proposedSolution:
      'A structured ingestion pipeline that extracts fields from incoming documents, validates totals against business rules, and flags exceptions for rapid human approval.',
    features: [
      'Automated extraction of vendor details, line items, and RM totals from uploaded documents',
      'Deterministic validation rules checking arithmetic accuracy and duplicate invoice numbers',
      'Human-in-the-loop review queue with side-by-side source document highlighting',
      'Webhook export of verified records into ERP and accounting databases',
    ],
    technologies: ['TypeScript', 'React', 'Node.js', 'Structured AI Extraction', 'REST Webhooks'],
    imageUrl: AI_OPS_IMAGE_PATH,
    developmentProcess: [
      {
        phase: '01. Schema & Extraction Definition',
        detail: 'Defined strict JSON schemas for purchase orders, quotations, and service tickets.',
      },
      {
        phase: '02. Confidence & Rule Gating',
        detail: 'Built deterministic validation checks so low-confidence fields are routed to human review.',
      },
      {
        phase: '03. Operator Review Console',
        detail: 'Created a high-contrast split-pane verification UI for operations staff.',
      },
    ],
    architectureHighlights: [
      'Strict schema enforcement ensuring zero malformed records enter downstream databases',
      'Complete auditability of AI-extracted vs. human-edited fields',
    ],
  },
  {
    id: 'fieldpulse-mobile-companion',
    slug: 'fieldpulse-mobile',
    title: 'FieldPulse Technician Mobile Companion',
    subtitle: 'Sample Concept Architecture — iOS & Android Field Operations App',
    category: 'Mobile Applications',
    isFlagship: false,
    isSampleConcept: true,
    status: 'Sample Reference Architecture',
    overview:
      'A sample mobile application architecture designed to pair with enterprise systems like ServiceFlow, giving on-site technicians offline-resilient job checklists, asset QR scanning, and digital customer sign-off.',
    problemSolved:
      'Field engineers working in basements or industrial sites often lose mobile connectivity, preventing them from viewing job specs or recording parts used until they return to the office.',
    proposedSolution:
      'A mobile-first companion interface with local state caching, camera barcode scanning, and automatic background synchronization once connectivity is restored.',
    features: [
      'Daily route agenda with one-tap navigation and site contact details',
      'Step-by-step safety and maintenance inspection checklists',
      'On-device signature capture and photo attachment for service verification',
      'Instant synchronization with central dispatch upon job completion',
    ],
    technologies: ['React Native / PWA', 'TypeScript', 'Offline Sync Queue', 'REST API'],
    imageUrl: SERVICEFLOW_IMAGE_PATH,
    developmentProcess: [
      {
        phase: '01. Field Ergonomics Research',
        detail: 'Designed large, high-contrast touch targets operable with one hand in field environments.',
      },
      {
        phase: '02. Offline Queue Architecture',
        detail: 'Engineered idempotent sync queues to prevent duplicate job updates on flaky networks.',
      },
    ],
    architectureHighlights: [
      '44px+ minimum touch targets and high-contrast dark mode for indoor/outdoor legibility',
      'Direct API compatibility with ServiceFlow dispatch and inventory endpoints',
    ],
  },
  {
    id: 'fintech-design-system',
    slug: 'aura-ui-design-system',
    title: 'Aura UI — Enterprise Design System & Component Kit',
    subtitle: 'Sample Concept Architecture — Multi-Product UI/UX Token & Component Library',
    category: 'UI/UX Design',
    isFlagship: false,
    isSampleConcept: true,
    status: 'Sample Reference Architecture',
    overview:
      'A comprehensive UI/UX design system created by BUILD AURA to standardize typography, accessible color contrast, data tables, and form validation patterns across enterprise web applications.',
    problemSolved:
      'Growing software teams often build inconsistent interfaces across different modules, leading to usability friction, accessibility gaps, and slow frontend delivery.',
    proposedSolution:
      'A unified token and component specification enforcing WCAG AA contrast, tabular numeric alignment, keyboard navigation, and zero-clutter layouts.',
    features: [
      'Semantic color tokens calibrated for dark and light enterprise workspaces',
      'Accessible form primitives with inline validation, error summaries, and focus rings',
      'High-density data table patterns with sorting, filtering, and status indicators',
      'Interactive Figma-to-React component parity documentation',
    ],
    technologies: ['UI/UX Architecture', 'Design Tokens', 'React', 'Tailwind CSS', 'WCAG AA Accessibility'],
    imageUrl: HERO_IMAGE_PATH,
    developmentProcess: [
      {
        phase: '01. Typographic & Spatial Audit',
        detail: 'Established modular type scales and 4px/8px spatial rhythm rules.',
      },
      {
        phase: '02. Accessible Component Primitives',
        detail: 'Built keyboard-navigable modals, tabs, filters, and validated inputs.',
      },
    ],
    architectureHighlights: [
      'Strict 4.5:1 minimum text contrast across all surface elevations',
      'Reusable patterns that accelerate new project delivery at BUILD AURA',
    ],
  },
];

export const DEVELOPMENT_PROCESS: ProcessPhase[] = [
  {
    step: '01',
    title: 'Discovery and Requirements Gathering',
    durationNote: 'Phase 1 · Alignment & Scope',
    summary:
      'We begin by understanding your business model, operational bottlenecks, target users, and measurable success criteria before writing a single line of code.',
    activities: [
      'Stakeholder interviews and current workflow audit',
      'Identification of core user roles, pain points, and integration needs',
      'Prioritization of Minimum Viable Product (MVP) vs. future expansion phases',
    ],
    deliverables: ['Functional Requirements Specification', 'Project Scope & Milestone Roadmap', 'Itemised RM Quotation'],
  },
  {
    step: '02',
    title: 'Planning and Technical Architecture',
    durationNote: 'Phase 2 · System Blueprint',
    summary:
      'We select the right technology stack, design the relational database schema, and define API contracts and security boundaries to ensure long-term scalability.',
    activities: [
      'Database entity-relationship modeling and data integrity rules',
      'Selection of frontend, backend, hosting, and third-party service integrations',
      'Role-based access control (RBAC) and security architecture planning',
    ],
    deliverables: ['Technical Architecture Blueprint', 'Database Schema Specification', 'API Contract Definitions'],
  },
  {
    step: '03',
    title: 'UI/UX Design and Prototyping',
    durationNote: 'Phase 3 · Interface & Experience',
    summary:
      'We craft clean, intuitive wireframes and high-fidelity interactive prototypes so you can experience and refine the user journey early.',
    activities: [
      'Information architecture and user flow mapping',
      'High-contrast, responsive UI design across desktop, tablet, and mobile viewports',
      'Interactive prototype walkthrough and stakeholder feedback incorporation',
    ],
    deliverables: ['Responsive UI Screens', 'Design Token & Component Guide', 'Approved Interactive Prototype'],
  },
  {
    step: '04',
    title: 'Development and Implementation',
    durationNote: 'Phase 4 · Iterative Engineering',
    summary:
      'Our engineering team builds the frontend, backend APIs, and database layers in structured milestones with regular staging previews.',
    activities: [
      'Modular frontend component development with TypeScript and Tailwind CSS',
      'Secure backend API implementation, validation, and database integration',
      'Milestone staging deployments so you can review real working progress',
    ],
    deliverables: ['Production-Grade Source Code', 'Staging Preview Environment', 'Integrated Backend & Database'],
  },
  {
    step: '05',
    title: 'Testing and Quality Assurance',
    durationNote: 'Phase 5 · Verification & Hardening',
    summary:
      'Every feature undergoes functional testing, cross-device responsiveness checks, form validation verification, and security review.',
    activities: [
      'End-to-end user workflow testing and edge-case validation',
      'Mobile, tablet, and desktop layout and keyboard accessibility checks',
      'Performance profiling, query optimization, and security authorization verification',
    ],
    deliverables: ['QA Verification Checklist', 'Performance & Accessibility Audit', 'User Acceptance Testing (UAT) Sign-Off'],
  },
  {
    step: '06',
    title: 'Deployment and Launch',
    durationNote: 'Phase 6 · Go-Live Execution',
    summary:
      'We configure your production cloud environment, SSL certificates, custom domain routing, and automated backups for a smooth launch.',
    activities: [
      'Production server, database, and environment variable provisioning',
      'Custom domain DNS, HTTPS/SSL security, and email/webhook notification setup',
      'Administrator onboarding, documentation handover, and live launch verification',
    ],
    deliverables: ['Live Production Application', 'Admin & Operations Documentation', 'Deployment & Backup Configuration'],
  },
  {
    step: '07',
    title: 'Maintenance and Continuous Improvement',
    durationNote: 'Phase 7 · Long-Term Partnership',
    summary:
      'After launch, we remain your technology partner—monitoring performance, applying security updates, and building new capabilities as your business expands.',
    activities: [
      'Ongoing dependency updates, uptime monitoring, and database care',
      'User feedback analysis and iterative workflow enhancements',
      'Planned rollout of Phase 2/3 expansions (client portals, mobile companions, AI automations)',
    ],
    deliverables: ['Scheduled Maintenance Updates', 'Priority Technical Support', 'Iterative Feature Releases'],
  },
];

export const CLIENT_EXPANSION_ROADMAP = [
  {
    phase: 'Phase 1 (Active)',
    title: 'Public Digital Presence & Real Enquiry Engine',
    status: 'Operational',
    items: [
      'Complete multi-page architecture (Home, Services, Portfolio, ServiceFlow Case Study, Process, About, Contact)',
      'Validated Project Enquiry API with persistent backend storage and reference code generation',
      'Live Enquiry Status Lookup & Secure Administrator Console',
    ],
  },
  {
    phase: 'Phase 2 (Ready to Configure)',
    title: 'External Email, Cloud Database & Storage',
    status: 'Architecture Prepared',
    items: [
      'Automated email notifications via Resend / SendGrid / SMTP or webhook integration',
      'Cloud SQL (PostgreSQL) or Cloud Firestore production database connection',
      'Cloud object storage for multi-file project specifications and quotation PDFs',
    ],
  },
  {
    phase: 'Phase 3 (Expandable Module)',
    title: 'Client Portal & Quotation Approval Workspace',
    status: 'Modular Blueprint',
    items: [
      'Authenticated client login with project milestone progress tracking',
      'Digital quotation review, revision comments, and one-click quotation approval',
      'Invoice ledger, payment gateway integration (FPX / Stripe), and support ticketing',
    ],
  },
];
