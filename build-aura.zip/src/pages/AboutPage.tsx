import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, ShieldCheck, Layers, Cpu, Users, Lock, Sparkles } from 'lucide-react';

export const AboutPage: React.FC = () => {
  const coreValues = [
    {
      icon: Layers,
      title: 'Clarity Over Complexity',
      description:
        'Enterprise software does not need to feel cluttered or confusing. We design clean, self-explanatory workflows that reduce staff training time and eliminate operational guesswork.',
    },
    {
      icon: ShieldCheck,
      title: 'Uncompromising Quality & Security',
      description:
        'From strict TypeScript typing and database constraints to server-side authorization and secret isolation, we treat security and reliability as foundational requirements—never afterthoughts.',
    },
    {
      icon: Users,
      title: 'True Technology Partnership',
      description:
        'We do not just hand over code and disappear. We listen carefully to how your business operates, challenge assumptions constructively, and build systems that serve your long-term goals.',
    },
    {
      icon: Cpu,
      title: 'Practical Innovation',
      description:
        'We apply modern web frameworks, cloud infrastructure, and artificial intelligence where they deliver genuine efficiency—helping teams automate repetitive tasks and make faster decisions.',
    },
    {
      icon: Lock,
      title: 'Radical Honesty & Transparency',
      description:
        'We provide straightforward technical advice, realistic timelines, and itemised quotations in Malaysian Ringgit (RM) with zero hidden fees or exaggerated claims.',
    },
    {
      icon: Sparkles,
      title: 'Continuous Improvement',
      description:
        'Great digital products evolve alongside their users. We structure every application with clean modular boundaries so new capabilities can be added smoothly over time.',
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-6 py-14 space-y-20">
      {/* Company Introduction */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        <div className="lg:col-span-7 space-y-5">
          <div className="flex items-center gap-2 text-xs font-medium text-sky-400">
            <span>About BUILD AURA</span>
            <span aria-hidden="true">·</span>
            <span className="text-slate-400">Build Beyond Expectations.</span>
          </div>

          <h1
            className="text-3xl md:text-5xl font-extrabold text-white font-display tracking-tight"
            style={{ textWrap: 'balance' }}
          >
            Engineering Practical, High-Impact Digital Solutions for Modern Businesses
          </h1>

          <p className="text-base md:text-lg text-slate-300 leading-relaxed">
            <strong className="text-white font-semibold">BUILD AURA</strong> is a technology and software engineering company dedicated to helping individuals, startups, and established enterprises transform ideas into resilient digital products.
          </p>

          <p className="text-sm md:text-base text-slate-300 leading-relaxed">
            We specialise in custom website development, e-commerce platforms, Android and iOS mobile applications, bespoke business management systems—such as our flagship <strong className="text-white font-semibold">ServiceFlow</strong> platform—and AI-powered workflow automation. Rather than forcing your business into rigid generic templates, we engineer software around how your organization actually creates value.
          </p>
        </div>

        {/* Mission & Vision Panel */}
        <div className="lg:col-span-5 space-y-5">
          <div className="rounded-2xl bg-[#0B1120] border border-slate-800 p-7 space-y-3">
            <p className="text-xs font-mono text-sky-400">OUR MISSION</p>
            <h2 className="text-xl font-bold text-white font-display">
              Empowering Organisations Through Dependable Software
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed">
              To design and deliver custom websites, mobile apps, and intelligent management systems that eliminate operational friction, strengthen customer trust, and allow businesses to scale with confidence.
            </p>
          </div>

          <div className="rounded-2xl bg-[#0B1120] border border-slate-800 p-7 space-y-3">
            <p className="text-xs font-mono text-sky-400">OUR VISION</p>
            <h2 className="text-xl font-bold text-white font-display">
              Build Beyond Expectations
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed">
              To be the trusted technology partner for forward-thinking businesses across Malaysia and beyond—recognized for architectural craftsmanship, honest engineering, and software that delivers real-world impact.
            </p>
          </div>
        </div>
      </div>

      {/* Development Philosophy */}
      <section className="rounded-2xl bg-[#0B1120] border border-slate-800 p-8 md:p-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          <div className="lg:col-span-5 space-y-3">
            <p className="text-xs font-medium text-sky-400">Our Engineering Philosophy</p>
            <h2 className="text-2xl md:text-3xl font-bold text-white font-display tracking-tight">
              Why Custom Architecture Matters
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed">
              Off-the-shelf templates often look acceptable on day one, but quickly break down when your business needs custom quotation logic, technician dispatch rules, role-based staff permissions, or API integrations.
            </p>
          </div>

          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="p-6 rounded-xl bg-[#060913] border border-slate-800 space-y-2">
              <p className="text-xs font-mono text-sky-400">01 / USER-FIRST DESIGN</p>
              <h3 className="text-base font-bold text-white font-display">
                Usability & Accessibility
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Every interface is designed with high-contrast legibility, logical keyboard navigation, and responsive layouts that perform smoothly on desktop monitors, tablets, and field smartphones.
              </p>
            </div>

            <div className="p-6 rounded-xl bg-[#060913] border border-slate-800 space-y-2">
              <p className="text-xs font-mono text-sky-400">02 / CLEAN CODEBASE</p>
              <h3 className="text-base font-bold text-white font-display">
                Maintainable TypeScript Stack
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                We write modular, strongly-typed code with clear separation between UI components, business services, API endpoints, and database schemas—making future upgrades straightforward.
              </p>
            </div>

            <div className="p-6 rounded-xl bg-[#060913] border border-slate-800 space-y-2">
              <p className="text-xs font-mono text-sky-400">03 / DATA INTEGRITY</p>
              <h3 className="text-base font-bold text-white font-display">
                Normalized Schemas & Validation
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Whether tracking quotations, inventory, or customer enquiries, we validate inputs on both client and server so your operational reports remain accurate and trustworthy.
              </p>
            </div>

            <div className="p-6 rounded-xl bg-[#060913] border border-slate-800 space-y-2">
              <p className="text-xs font-mono text-sky-400">04 / LONG-TERM OWNERSHIP</p>
              <h3 className="text-base font-bold text-white font-display">
                No Vendor Lock-In Traps
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                We document environment variables, deployment steps, and database schemas clearly so you remain in full control of your digital infrastructure and domain.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Core Values Grid */}
      <section className="space-y-8">
        <div className="space-y-2 max-w-2xl">
          <p className="text-xs font-medium text-sky-400">Core Values & Standards</p>
          <h2 className="text-2xl md:text-3xl font-bold text-white font-display tracking-tight">
            Our Commitment on Every Project
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {coreValues.map((val) => {
            const IconComponent = val.icon;
            return (
              <div
                key={val.title}
                className="rounded-2xl bg-[#0B1120] border border-slate-800/90 p-7 space-y-3"
              >
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-sky-400">
                  <IconComponent className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-white font-display">
                  {val.title}
                </h3>
                <p className="text-sm text-slate-300 leading-relaxed">
                  {val.description}
                </p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Call to Action */}
      <section className="rounded-2xl bg-gradient-to-r from-[#0F172A] via-[#131C31] to-[#1E1B4B] border border-slate-700/80 p-8 md:p-12 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2 max-w-2xl">
          <p className="text-xs font-medium text-sky-400">Partner With BUILD AURA</p>
          <h2 className="text-2xl md:text-3xl font-bold text-white font-display">
            Have a Business Problem That Better Software Can Solve?
          </h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            Tell us about your current workflow or product vision. We will help you map out a clear, practical path from concept to deployment.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-4 shrink-0">
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 px-6 py-3.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition-colors whitespace-nowrap shrink-0"
          >
            <span>Contact BUILD AURA</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
          <Link
            to="/process"
            className="px-5 py-3.5 text-sm font-semibold text-slate-200 hover:text-white bg-slate-900 border border-slate-700 rounded-xl transition-colors whitespace-nowrap shrink-0"
          >
            View Our Process
          </Link>
        </div>
      </section>
    </div>
  );
};
