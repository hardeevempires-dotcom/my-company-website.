import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import type { SiteSettings } from '../types';

interface LegalPageProps {
  mode: 'privacy' | 'terms';
  settings: SiteSettings;
}

export const LegalPage: React.FC<LegalPageProps> = ({ mode, settings }) => {
  return (
    <div className="max-w-4xl mx-auto px-6 py-14 space-y-10">
      <Link
        to="/"
        className="inline-flex items-center gap-2 text-xs font-semibold text-slate-400 hover:text-white transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Home</span>
      </Link>

      {mode === 'privacy' ? (
        <article className="rounded-2xl bg-[#0B1120] border border-slate-800 p-8 md:p-12 space-y-6 text-sm text-slate-300 leading-relaxed">
          <div className="border-b border-slate-800 pb-6 space-y-2">
            <p className="text-xs font-mono text-sky-400">LEGAL GOVERNANCE · EDITABLE POLICY TEMPLATE</p>
            <h1 className="text-3xl font-extrabold text-white font-display">
              Privacy Policy — {settings.companyName}
            </h1>
            <p className="text-xs text-slate-400">
              Effective Year: {new Date().getFullYear()} · Compliant with Malaysian Personal Data Protection Act (PDPA) principles
            </p>
          </div>

          <section className="space-y-2">
            <h2 className="text-lg font-bold text-white font-display">
              1. Information We Collect
            </h2>
            <p>
              When you submit a project enquiry through {settings.companyName}, we collect only the information necessary to evaluate your technical requirements and prepare a quotation: your full name, email address, phone or WhatsApp number, company name, selected service, estimated budget in Malaysian Ringgit (RM), preferred timeline, and project description.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-lg font-bold text-white font-display">
              2. How We Use Your Data
            </h2>
            <p>
              Your enquiry records are used strictly to communicate with you regarding your software project, prepare technical proposals, and provide status updates via your unique Enquiry Reference Code. We never sell, rent, or trade client contact information or project specifications to third parties.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-lg font-bold text-white font-display">
              3. Data Security & Access Controls
            </h2>
            <p>
              Enquiry submissions are validated server-side and restricted to authorised {settings.companyName} engineering administrators. Public visitors cannot access private client contact details or confidential project descriptions.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-lg font-bold text-white font-display">
              4. Contact & Data Requests
            </h2>
            <p>
              To request access to, correction of, or deletion of your project enquiry record, please contact us at{' '}
              <span className="text-sky-400 font-mono">{settings.contactEmail}</span> quoting your Enquiry Reference Code.
            </p>
          </section>
        </article>
      ) : (
        <article className="rounded-2xl bg-[#0B1120] border border-slate-800 p-8 md:p-12 space-y-6 text-sm text-slate-300 leading-relaxed">
          <div className="border-b border-slate-800 pb-6 space-y-2">
            <p className="text-xs font-mono text-sky-400">LEGAL GOVERNANCE · EDITABLE TERMS TEMPLATE</p>
            <h1 className="text-3xl font-extrabold text-white font-display">
              Terms of Service — {settings.companyName}
            </h1>
            <p className="text-xs text-slate-400">
              Standard Software Engineering & Digital Consulting Terms
            </p>
          </div>

          <section className="space-y-2">
            <h2 className="text-lg font-bold text-white font-display">
              1. Project Quotations & Scope of Work
            </h2>
            <p>
              All budget ranges displayed on this website in Malaysian Ringgit (RM) are indicative starting guides. Formal software development engagements with {settings.companyName} are governed by a written Project Specification and Quotation detailing exact deliverables, milestone schedules, and acceptance criteria.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-lg font-bold text-white font-display">
              2. Intellectual Property & Code Ownership
            </h2>
            <p>
              Unless otherwise specified in a written agreement, custom application code, database schemas, and brand assets developed specifically for a client become the client’s property upon full settlement of agreed milestone invoices. Flagship products such as ServiceFlow remain the intellectual property of {settings.companyName} and are licensed or customised per agreement.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-lg font-bold text-white font-display">
              3. Confidentiality
            </h2>
            <p>
              {settings.companyName} treats all project briefs, business workflows, and operational documents shared during the enquiry and discovery process as strictly confidential.
            </p>
          </section>
        </article>
      )}
    </div>
  );
};
