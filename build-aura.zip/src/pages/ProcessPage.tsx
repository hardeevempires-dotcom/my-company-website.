import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle2, Layers } from 'lucide-react';
import { DEVELOPMENT_PROCESS, CLIENT_EXPANSION_ROADMAP } from '../data/catalog';

export const ProcessPage: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-6 py-14 space-y-20">
      {/* Header */}
      <div className="space-y-4 max-w-3xl">
        <div className="flex items-center gap-2 text-xs font-medium text-sky-400">
          <span>Engineering Methodology</span>
          <span aria-hidden="true">·</span>
          <span className="text-slate-400">7-Stage Lifecycle</span>
        </div>
        <h1
          className="text-3xl md:text-5xl font-extrabold text-white font-display tracking-tight"
          style={{ textWrap: 'balance' }}
        >
          A Transparent, Predictable Workflow From Discovery to Continuous Care
        </h1>
        <p className="text-base md:text-lg text-slate-300 leading-relaxed">
          Great software is never accidental. At BUILD AURA, every project follows a structured seven-stage engineering lifecycle so you always know what is being built, why architectural decisions are made, and when milestones will be delivered.
        </p>
      </div>

      {/* 7-Stage Process Cards */}
      <div className="space-y-6">
        {DEVELOPMENT_PROCESS.map((phase) => (
          <section
            key={phase.step}
            className="rounded-2xl bg-[#0B1120] border border-slate-800/90 p-7 md:p-9"
          >
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              {/* Step Identity & Summary */}
              <div className="lg:col-span-5 space-y-3">
                <div className="flex items-center gap-2 text-xs font-mono text-sky-400 tabular-nums">
                  <span>STEP {phase.step}</span>
                  <span aria-hidden="true">·</span>
                  <span className="text-slate-400">{phase.durationNote}</span>
                </div>
                <h2 className="text-2xl font-bold text-white font-display tracking-tight">
                  {phase.step}. {phase.title}
                </h2>
                <p className="text-sm text-slate-300 leading-relaxed">
                  {phase.summary}
                </p>
              </div>

              {/* Key Engineering Activities */}
              <div className="lg:col-span-4 space-y-2.5">
                <h3 className="text-xs font-semibold text-slate-200 tracking-wide">
                  Key Engineering Activities
                </h3>
                <ul className="space-y-2">
                  {phase.activities.map((activity, idx) => (
                    <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-400 leading-relaxed">
                      <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                      <span>{activity}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Concrete Deliverables */}
              <div className="lg:col-span-3 rounded-xl bg-[#060913] border border-slate-800 p-5 space-y-2.5">
                <h3 className="text-xs font-semibold text-white">
                  Stage Deliverables
                </h3>
                <ul className="space-y-2 text-xs text-slate-300 font-mono">
                  {phase.deliverables.map((deliv, idx) => (
                    <li key={idx} className="flex items-center gap-2">
                      <span className="text-sky-400">→</span>
                      <span className="font-sans">{deliv}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </section>
        ))}
      </div>

      {/* Expandable Platform Architecture Roadmap */}
      <section className="rounded-2xl bg-[#0B1120] border border-slate-800 p-8 md:p-12 space-y-8">
        <div className="space-y-3 max-w-3xl">
          <div className="flex items-center gap-2 text-xs font-medium text-sky-400">
            <Layers className="w-4 h-4" />
            <span>Modular Platform Expansion Blueprint</span>
          </div>
          <h2 className="text-2xl md:text-3xl font-bold text-white font-display tracking-tight">
            Built to Scale: From Phase 1 Launch to Full Client Portals
          </h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            We architect every platform so you can launch quickly without accumulating technical debt. Additional client-facing modules—such as customer account registration, quotation approval workflows, support ticketing, and invoice settlement—can be activated incrementally as your operations grow.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {CLIENT_EXPANSION_ROADMAP.map((stage) => (
            <div
              key={stage.phase}
              className="rounded-xl bg-[#060913] border border-slate-800 p-6 flex flex-col justify-between space-y-5"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-sky-400">{stage.phase}</span>
                  <span className="text-slate-400">{stage.status}</span>
                </div>
                <h3 className="text-base font-bold text-white font-display">
                  {stage.title}
                </h3>
                <ul className="space-y-2 pt-1">
                  {stage.items.map((item, idx) => (
                    <li key={idx} className="text-xs text-slate-400 leading-relaxed">
                      • {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

        <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <p className="text-xs text-slate-400">
            Have an existing project Reference Code? You can inspect live enquiry status in our Enquiry Tracker.
          </p>
          <div className="flex items-center gap-3">
            <Link
              to="/portal"
              className="px-4 py-2.5 text-xs font-semibold text-slate-200 hover:text-white bg-slate-900 border border-slate-700 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              Open Enquiry Tracker
            </Link>
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              <span>Start Step 01 Discovery</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};
