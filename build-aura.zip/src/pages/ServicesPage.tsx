import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, CheckCircle2, Calculator } from 'lucide-react';
import type { ServiceItem } from '../types';
import { ServiceIcon } from '../components/ServiceIcon';

interface ServicesPageProps {
  services: ServiceItem[];
}

export const ServicesPage: React.FC<ServicesPageProps> = ({ services }) => {
  const navigate = useNavigate();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedScopeIds, setSelectedScopeIds] = useState<string[]>(['website-design-dev']);

  const categories = ['All', ...Array.from(new Set(services.map((s) => s.category)))];

  const filteredServices =
    selectedCategory === 'All'
      ? services
      : services.filter((s) => s.category === selectedCategory);

  const toggleScopeSelection = (id: string) => {
    setSelectedScopeIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const selectedServiceObjects = services.filter((s) => selectedScopeIds.includes(s.id));

  const handleBundledQuote = () => {
    if (selectedServiceObjects.length === 0) return;
    const title =
      selectedServiceObjects.length === 1
        ? selectedServiceObjects[0].title
        : selectedServiceObjects.map((s) => s.title).join(', ');
    navigate(`/contact?service=${encodeURIComponent(title)}`);
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-14 space-y-20">
      {/* Page Header */}
      <div className="space-y-4 max-w-3xl">
        <div className="flex items-center gap-2 text-xs font-medium text-sky-400">
          <span>BUILD AURA Capabilities</span>
          <span aria-hidden="true">·</span>
          <span className="text-slate-400">12 Specialized Engineering Services</span>
        </div>
        <h1
          className="text-3xl md:text-5xl font-extrabold text-white font-display tracking-tight"
          style={{ textWrap: 'balance' }}
        >
          Software Engineering, Product Design & Intelligent Automation
        </h1>
        <p className="text-base md:text-lg text-slate-300 leading-relaxed">
          From high-converting corporate websites and mobile apps to custom enterprise management systems like ServiceFlow, every solution is architected for reliability, security, and measurable business growth.
        </p>
      </div>

      {/* Interactive Filter Control */}
      <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-[#0B1120] border border-slate-800 rounded-xl w-fit">
        {categories.map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => setSelectedCategory(cat)}
            className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              selectedCategory === cat
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* 12 Service Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredServices.map((service) => (
          <article
            key={service.id}
            className="rounded-2xl bg-[#0B1120] border border-slate-800/90 hover:border-slate-700 p-7 flex flex-col justify-between transition-colors"
          >
            <div className="space-y-4">
              <div className="flex items-center justify-between gap-4">
                <div className="text-xs font-mono text-slate-400 tabular-nums">
                  <span>{service.index}</span>
                  <span aria-hidden="true"> · </span>
                  <span className="text-sky-400">{service.category}</span>
                </div>
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/25 flex items-center justify-center text-sky-400 shrink-0">
                  <ServiceIcon name={service.iconName} className="w-5 h-5" />
                </div>
              </div>

              <h2 className="text-xl font-bold text-white font-display tracking-tight">
                {service.title}
              </h2>

              <p className="text-sm text-slate-300 leading-relaxed">
                {service.fullDescription}
              </p>

              <div className="pt-2 space-y-2">
                <p className="text-xs font-semibold text-slate-200">Key Business Benefits</p>
                <ul className="space-y-2">
                  {service.benefits.map((benefit, idx) => (
                    <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-400 leading-relaxed">
                      <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                      <span>{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="pt-6 mt-6 border-t border-slate-800/80 space-y-4">
              <div className="flex items-center justify-between text-xs font-mono text-slate-400 tabular-nums">
                <span>Timeline: {service.typicalTimeline}</span>
                <span className="text-slate-300">{service.startingEstimateRM}</span>
              </div>

              <div className="text-xs text-slate-500">
                Deliverables: {service.deliverables.join(' · ')}
              </div>

              <Link
                to={`/contact?service=${encodeURIComponent(service.title)}`}
                className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition-colors flex items-center justify-center gap-2 whitespace-nowrap shrink-0"
              >
                <span>Request a Quote</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </article>
        ))}
      </div>

      {/* Interactive Scope & Deliverable Planner */}
      <section className="rounded-2xl bg-[#0B1120] border border-slate-800 p-8 md:p-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          <div className="lg:col-span-7 space-y-5">
            <div className="flex items-center gap-2 text-xs font-medium text-sky-400">
              <Calculator className="w-4 h-4" />
              <span>Interactive Project Scope Planner</span>
            </div>
            <h2 className="text-2xl font-bold text-white font-display tracking-tight">
              Combine Multiple Capabilities Into One Cohesive Proposal
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed">
              Many projects combine multiple disciplines—such as UI/UX Design, Custom Software Development, and Cloud Deployment. Select the services you are considering below to bundle them into your enquiry brief.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
              {services.map((s) => {
                const isSelected = selectedScopeIds.includes(s.id);
                return (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => toggleScopeSelection(s.id)}
                    className={`p-3 rounded-xl border text-left transition-colors flex items-center justify-between gap-3 cursor-pointer ${
                      isSelected
                        ? 'bg-blue-600/15 border-sky-400 text-white'
                        : 'bg-[#060913] border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                    }`}
                  >
                    <span className="text-xs font-medium truncate">
                      {s.index}. {s.title}
                    </span>
                    <span className="text-[11px] font-mono text-sky-400 shrink-0">
                      {isSelected ? 'Selected' : '+ Add'}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="lg:col-span-5 rounded-xl bg-[#060913] border border-slate-800 p-6 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <h3 className="text-base font-bold text-white font-display">
                Selected Project Scope ({selectedServiceObjects.length}{' '}
                {selectedServiceObjects.length === 1 ? 'Service' : 'Services'})
              </h3>

              {selectedServiceObjects.length === 0 ? (
                <p className="text-xs text-slate-500 py-6">
                  Select one or more services on the left to preview combined deliverables and request a bundled quotation.
                </p>
              ) : (
                <ul className="space-y-3 max-h-64 overflow-y-auto pr-1">
                  {selectedServiceObjects.map((item) => (
                    <li
                      key={item.id}
                      className="pb-3 border-b border-slate-800/80 last:border-none"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-semibold text-white">{item.title}</span>
                        <span className="text-[11px] font-mono text-sky-400 shrink-0 tabular-nums">
                          {item.startingEstimateRM}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-1">
                        Deliverables: {item.deliverables.join(' · ')}
                      </p>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div className="pt-4 border-t border-slate-800 space-y-3">
              <p className="text-xs text-slate-400">
                Final quotations in RM are tailored to your exact feature scope, integration requirements, and timeline.
              </p>
              <button
                type="button"
                disabled={selectedServiceObjects.length === 0}
                onClick={handleBundledQuote}
                className="w-full py-3 px-4 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 disabled:opacity-40 rounded-xl transition-colors cursor-pointer"
              >
                Request Custom Quotation for Selected Scope →
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
