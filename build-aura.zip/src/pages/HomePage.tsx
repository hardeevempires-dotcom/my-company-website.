import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle2, ShieldCheck, Layers, Code2, Cpu } from 'lucide-react';
import type { ProjectItem, ServiceItem } from '../types';
import { HERO_IMAGE_PATH, DEVELOPMENT_PROCESS } from '../data/catalog';
import { ResilientImage } from '../components/ResilientImage';
import { ServiceIcon } from '../components/ServiceIcon';

interface HomePageProps {
  services: ServiceItem[];
  projects: ProjectItem[];
}

export const HomePage: React.FC<HomePageProps> = ({ services, projects }) => {
  const featuredServices = services.slice(0, 6);
  const flagshipProject = projects.find((p) => p.slug === 'serviceflow') || projects[0];
  const secondaryProjects = projects.filter((p) => p.id !== flagshipProject?.id).slice(0, 2);

  return (
    <div className="space-y-28 pb-24">
      {/* 1. HERO SECTION */}
      <section className="relative pt-12 md:pt-20 overflow-hidden">
        {/* Subtle atmospheric radial gradient */}
        <div
          className="pointer-events-none absolute -top-40 left-1/2 -translate-x-1/2 w-[960px] h-[480px] rounded-full bg-gradient-to-tr from-blue-600/15 via-sky-400/10 to-purple-600/15 blur-3xl"
          aria-hidden="true"
        />

        <div className="max-w-7xl mx-auto px-6 relative">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
            {/* Left Column: Value Proposition */}
            <div className="lg:col-span-7 flex flex-col justify-center space-y-6">
              <div className="flex items-center gap-3 text-xs font-medium text-sky-400 tracking-wide">
                <span>BUILD AURA</span>
                <span aria-hidden="true">·</span>
                <span className="text-slate-300">Build Beyond Expectations.</span>
              </div>

              <h1
                className="font-display font-extrabold tracking-tight text-white leading-[1.08]"
                style={{ fontSize: 'clamp(2.35rem, 4.2vw, 3.85rem)', textWrap: 'balance' }}
              >
                Your Vision. Our Technology.{' '}
                <span className="bg-gradient-to-r from-sky-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">
                  Real Impact.
                </span>
              </h1>

              <p className="text-base md:text-lg text-slate-300 leading-relaxed max-w-2xl">
                BUILD AURA designs and develops websites, mobile applications, and intelligent software systems that help businesses work smarter, solve problems, and grow with confidence.
              </p>

              <div className="flex flex-wrap items-center gap-4 pt-2">
                <Link
                  to="/contact"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition-colors whitespace-nowrap shrink-0"
                >
                  <span>Start a Project</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>

                <Link
                  to="/portfolio"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-slate-200 hover:text-white bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 rounded-xl transition-colors whitespace-nowrap shrink-0"
                >
                  <span>Explore Our Work</span>
                </Link>
              </div>

              <div className="pt-4 border-t border-slate-800/80 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-slate-400">
                <span>Custom Web & Mobile Platforms</span>
                <span aria-hidden="true">·</span>
                <span>Business Management Systems</span>
                <span aria-hidden="true">·</span>
                <span>Applied AI & Automation</span>
              </div>
            </div>

            {/* Right Column: High-Impact 16:9 Architectural Software Showcase */}
            <div className="lg:col-span-5 flex flex-col">
              <div className="relative flex-1 rounded-2xl overflow-hidden border border-slate-800 bg-[#0B1120] min-h-[300px] lg:min-h-full">
                <ResilientImage
                  src={HERO_IMAGE_PATH}
                  alt="BUILD AURA software engineering workspace displaying enterprise operational analytics"
                  fallbackTitle="BUILD AURA Engineering Studio"
                  fallbackSubtitle="Custom Web, Mobile, and Enterprise Software Architecture"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#060913] via-[#060913]/30 to-transparent" />
                <div className="absolute bottom-0 inset-x-0 p-6 flex items-end justify-between gap-4">
                  <div>
                    <p className="text-xs text-sky-400 font-medium">Featured System Architecture</p>
                    <p className="text-base font-bold text-white font-display mt-0.5">
                      ServiceFlow — Operations & Service Management
                    </p>
                    <p className="text-xs text-slate-300 mt-1">
                      Requests · Quotations · Dispatch · Invoicing · Inventory
                    </p>
                  </div>
                  <Link
                    to="/portfolio/serviceflow"
                    className="px-3.5 py-2 text-xs font-semibold text-white bg-slate-900/90 hover:bg-blue-600 border border-slate-700 rounded-lg transition-colors whitespace-nowrap shrink-0"
                  >
                    Case Study →
                  </Link>
                </div>
              </div>
            </div>
          </div>

          {/* Full-width 4-column Architectural Pillars Strip below Hero */}
          <div className="mt-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 pt-8 border-t border-slate-800/80">
            <div>
              <p className="text-xs font-mono text-sky-400 tabular-nums">01 / FULL-STACK DELIVERY</p>
              <p className="text-sm font-semibold text-white mt-1">Web, Mobile & Cloud Systems</p>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Unified engineering from responsive interfaces to normalized databases and secure APIs.
              </p>
            </div>
            <div>
              <p className="text-xs font-mono text-sky-400 tabular-nums">02 / OPERATIONAL CLARITY</p>
              <p className="text-sm font-semibold text-white mt-1">Built Around Real Workflows</p>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Software tailored to how your team quotes, dispatches, bills, and serves customers.
              </p>
            </div>
            <div>
              <p className="text-xs font-mono text-sky-400 tabular-nums">03 / SECURITY BY DESIGN</p>
              <p className="text-sm font-semibold text-white mt-1">Role-Based Access & Data Control</p>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Server-side validation, environment secret isolation, and strict authorization boundaries.
              </p>
            </div>
            <div>
              <p className="text-xs font-mono text-sky-400 tabular-nums">04 / TRANSPARENT SCOPE</p>
              <p className="text-sm font-semibold text-white mt-1">Structured Milestones in RM</p>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Clear specifications, predictable phases, and direct communication from discovery to launch.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 2. CORE SERVICES SHOWCASE */}
      <section className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-12 border-b border-slate-800/80">
          <div className="space-y-3 max-w-2xl">
            <p className="text-xs font-medium text-sky-400 tracking-wide">
              Core Engineering Capabilities
            </p>
            <h2
              className="text-2xl md:text-4xl font-bold text-white font-display tracking-tight"
              style={{ textWrap: 'balance' }}
            >
              End-to-End Digital Engineering Across 12 Specialized Disciplines
            </h2>
          </div>
          <Link
            to="/services"
            className="inline-flex items-center gap-2 text-sm font-semibold text-sky-400 hover:text-sky-300 transition-colors whitespace-nowrap shrink-0"
          >
            <span>View All 12 Services</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="mt-10 grid grid-cols-1 md:grid-cols-12 gap-6">
          {featuredServices.map((service, idx) => {
            const isWide = idx === 0 || idx === 4;
            return (
              <div
                key={service.id}
                className={`${
                  isWide ? 'md:col-span-7' : 'md:col-span-5'
                } rounded-2xl bg-[#0B1120] border border-slate-800/90 hover:border-slate-700 p-7 flex flex-col justify-between transition-colors`}
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between gap-4">
                    <span className="text-xs font-mono text-slate-400 tabular-nums">
                      {service.index}. {service.category}
                    </span>
                    <div className="w-9 h-9 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-sky-400">
                      <ServiceIcon name={service.iconName} className="w-4 h-4" />
                    </div>
                  </div>

                  <h3 className="text-xl font-bold text-white font-display tracking-tight">
                    {service.title}
                  </h3>

                  <p className="text-sm text-slate-300 leading-relaxed">
                    {service.shortDescription}
                  </p>

                  <ul className="space-y-2 pt-2">
                    {service.benefits.slice(0, 2).map((benefit, bIdx) => (
                      <li key={bIdx} className="flex items-start gap-2.5 text-xs text-slate-400">
                        <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                        <span>{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-6 mt-6 border-t border-slate-800/80 flex items-center justify-between gap-4">
                  <span className="text-xs font-mono text-slate-400 tabular-nums">
                    Timeline: {service.typicalTimeline}
                  </span>
                  <Link
                    to={`/contact?service=${encodeURIComponent(service.title)}`}
                    className="text-xs font-semibold text-sky-400 hover:text-sky-300 transition-colors whitespace-nowrap shrink-0"
                  >
                    Request a Quote →
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 3. FEATURED PROJECTS & SERVICEFLOW SPOTLIGHT */}
      <section className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-12 border-b border-slate-800/80">
          <div className="space-y-3 max-w-2xl">
            <p className="text-xs font-medium text-sky-400 tracking-wide">
              Featured Systems & Reference Architectures
            </p>
            <h2
              className="text-2xl md:text-4xl font-bold text-white font-display tracking-tight"
              style={{ textWrap: 'balance' }}
            >
              Software Engineered to Solve Real Operational Bottlenecks
            </h2>
          </div>
          <Link
            to="/portfolio"
            className="inline-flex items-center gap-2 text-sm font-semibold text-sky-400 hover:text-sky-300 transition-colors whitespace-nowrap shrink-0"
          >
            <span>Explore Full Portfolio</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        {/* Flagship Project: ServiceFlow */}
        {flagshipProject && (
          <div className="mt-10 rounded-2xl bg-[#0B1120] border border-slate-800 overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
              <div className="lg:col-span-7 p-8 md:p-10 flex flex-col justify-between space-y-6">
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-sky-400 font-medium">
                    <span>Flagship Product Architecture</span>
                    <span aria-hidden="true">·</span>
                    <span className="text-slate-400">{flagshipProject.category}</span>
                    <span aria-hidden="true">·</span>
                    <span className="text-slate-400">{flagshipProject.status}</span>
                  </div>

                  <h3 className="text-2xl md:text-3xl font-extrabold text-white font-display tracking-tight">
                    {flagshipProject.title} — {flagshipProject.subtitle}
                  </h3>

                  <p className="text-sm md:text-base text-slate-300 leading-relaxed">
                    {flagshipProject.overview}
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    {flagshipProject.modules?.map((mod, mIdx) => (
                      <div key={mIdx} className="p-3.5 rounded-xl bg-[#060913]/80 border border-slate-800/80">
                        <p className="text-xs font-semibold text-white">{mod.name}</p>
                        <p className="text-xs text-slate-400 mt-1">{mod.summary}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-4">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 font-mono">
                    {flagshipProject.technologies.map((tech, idx) => (
                      <React.Fragment key={tech}>
                        {idx > 0 && <span aria-hidden="true">·</span>}
                        <span>{tech}</span>
                      </React.Fragment>
                    ))}
                  </div>

                  <div className="flex items-center gap-3">
                    <Link
                      to="/portfolio/serviceflow"
                      className="px-4 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors whitespace-nowrap shrink-0"
                    >
                      Inspect ServiceFlow Architecture
                    </Link>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-5 bg-[#060913] border-t lg:border-t-0 lg:border-l border-slate-800 min-h-[280px]">
                <ResilientImage
                  src={flagshipProject.imageUrl}
                  alt={`${flagshipProject.title} enterprise dashboard mockup`}
                  fallbackTitle={flagshipProject.title}
                  fallbackSubtitle={flagshipProject.subtitle}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        )}

        {/* Secondary Reference Projects */}
        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          {secondaryProjects.map((project) => (
            <div
              key={project.id}
              className="rounded-2xl bg-[#0B1120] border border-slate-800/90 hover:border-slate-700 overflow-hidden flex flex-col justify-between transition-colors"
            >
              <div>
                <div className="aspect-[16/10] bg-[#060913] border-b border-slate-800 overflow-hidden">
                  <ResilientImage
                    src={project.imageUrl}
                    alt={project.title}
                    fallbackTitle={project.title}
                    fallbackSubtitle={project.category}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-7 space-y-3">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
                    <span className="text-sky-400 font-medium">{project.category}</span>
                    <span aria-hidden="true">·</span>
                    <span>{project.status}</span>
                  </div>
                  <h3 className="text-xl font-bold text-white font-display tracking-tight">
                    {project.title}
                  </h3>
                  <p className="text-sm text-slate-300 leading-relaxed">
                    {project.overview}
                  </p>
                </div>
              </div>

              <div className="px-7 pb-7 pt-4 border-t border-slate-800/60 flex items-center justify-between gap-4">
                <div className="text-xs text-slate-400 font-mono truncate">
                  {project.technologies.slice(0, 3).join(' · ')}
                </div>
                <Link
                  to={`/portfolio/${project.slug}`}
                  className="text-xs font-semibold text-sky-400 hover:text-sky-300 transition-colors whitespace-nowrap shrink-0"
                >
                  View Specification →
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. WHY CHOOSE BUILD AURA */}
      <section className="max-w-7xl mx-auto px-6">
        <div className="rounded-2xl bg-[#0B1120] border border-slate-800 p-8 md:p-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            <div className="lg:col-span-5 space-y-4">
              <p className="text-xs font-medium text-sky-400 tracking-wide">
                Why Partner With BUILD AURA
              </p>
              <h2
                className="text-2xl md:text-3xl font-bold text-white font-display tracking-tight"
                style={{ textWrap: 'balance' }}
              >
                Practical Engineering Standards Over Generic Templates
              </h2>
              <p className="text-sm text-slate-300 leading-relaxed">
                We partner with individuals, startups, and established enterprises to turn operational challenges into dependable software assets. Every system is engineered for clarity, maintainability, and measurable return on investment.
              </p>
              <div className="pt-2">
                <Link
                  to="/about"
                  className="inline-flex items-center gap-2 text-sm font-semibold text-sky-400 hover:text-sky-300 transition-colors"
                >
                  <span>Read Our Engineering Philosophy</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>

            <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="p-6 rounded-xl bg-[#060913] border border-slate-800/80 space-y-2.5">
                <Layers className="w-5 h-5 text-sky-400" />
                <h3 className="text-base font-bold text-white font-display">
                  Architecture Designed for Growth
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  We structure modular frontend and backend codebases so you can start with a focused Phase 1 launch and expand into client portals, mobile apps, or AI workflows without rewriting from scratch.
                </p>
              </div>

              <div className="p-6 rounded-xl bg-[#060913] border border-slate-800/80 space-y-2.5">
                <ShieldCheck className="w-5 h-5 text-sky-400" />
                <h3 className="text-base font-bold text-white font-display">
                  Security & Data Ownership
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Your business data and credentials remain strictly yours. We enforce server-side input validation, role-based access control, and environment secret isolation on every build.
                </p>
              </div>

              <div className="p-6 rounded-xl bg-[#060913] border border-slate-800/80 space-y-2.5">
                <Code2 className="w-5 h-5 text-sky-400" />
                <h3 className="text-base font-bold text-white font-display">
                  Direct Senior Engineering Collaboration
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Communicate directly with the software architect and developer building your product—ensuring your business logic is translated accurately into working software.
                </p>
              </div>

              <div className="p-6 rounded-xl bg-[#060913] border border-slate-800/80 space-y-2.5">
                <Cpu className="w-5 h-5 text-sky-400" />
                <h3 className="text-base font-bold text-white font-display">
                  Authentic Proof & Honest Reporting
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  We never fabricate vanity metrics or fictional reviews. We demonstrate our capabilities through live working architectures like ServiceFlow and transparent technical specifications.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. DEVELOPMENT WORKFLOW PREVIEW */}
      <section className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-10 border-b border-slate-800/80">
          <div className="space-y-2 max-w-2xl">
            <p className="text-xs font-medium text-sky-400 tracking-wide">
              Structured 7-Stage Delivery
            </p>
            <h2 className="text-2xl md:text-3xl font-bold text-white font-display tracking-tight">
              How We Take Your Project From Concept to Production
            </h2>
          </div>
          <Link
            to="/process"
            className="inline-flex items-center gap-2 text-sm font-semibold text-sky-400 hover:text-sky-300 transition-colors whitespace-nowrap shrink-0"
          >
            <span>Explore Full Process & Deliverables</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {DEVELOPMENT_PROCESS.slice(0, 4).map((phase) => (
            <div
              key={phase.step}
              className="p-6 rounded-xl bg-[#0B1120] border border-slate-800/80 flex flex-col justify-between space-y-4"
            >
              <div className="space-y-2.5">
                <span className="text-xs font-mono text-sky-400 tabular-nums">
                  STEP {phase.step}
                </span>
                <h3 className="text-base font-bold text-white font-display">
                  {phase.title}
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {phase.summary}
                </p>
              </div>
              <p className="text-xs text-slate-500 pt-3 border-t border-slate-800/70">
                Output: {phase.deliverables[0]}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* 6. STRONG CONTACT CALL TO ACTION */}
      <section className="max-w-7xl mx-auto px-6">
        <div className="rounded-2xl bg-gradient-to-r from-[#0F172A] via-[#131C31] to-[#1E1B4B] border border-slate-700/80 p-8 md:p-14 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8">
          <div className="space-y-3 max-w-2xl">
            <p className="text-xs font-medium text-sky-400 tracking-wide">
              Ready to Build Beyond Expectations?
            </p>
            <h2
              className="text-2xl md:text-4xl font-extrabold text-white font-display tracking-tight"
              style={{ textWrap: 'balance' }}
            >
              Let’s Architect Your Next Website, Mobile App, or Business System.
            </h2>
            <p className="text-sm md:text-base text-slate-300 leading-relaxed">
              Share your requirements, preferred timeline, and estimated budget in RM. Our engineering team will review your brief and prepare a structured technical recommendation.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-4 shrink-0">
            <Link
              to="/contact"
              className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition-colors whitespace-nowrap shrink-0"
            >
              <span>Discuss Your Idea</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              to="/services"
              className="inline-flex items-center justify-center px-6 py-3.5 text-sm font-semibold text-slate-200 hover:text-white bg-slate-900/90 hover:bg-slate-800 border border-slate-700 rounded-xl transition-colors whitespace-nowrap shrink-0"
            >
              View Our Services
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};
