import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Search, AlertCircle } from 'lucide-react';
import type { EnquirySubmission } from '../types';

export const PortalPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const refParam = searchParams.get('ref');

  const [referenceInput, setReferenceInput] = useState(refParam || 'BA-ENQ-DEMO');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [record, setRecord] = useState<Partial<EnquirySubmission> | null>(null);

  const lookupReference = useCallback(async (codeToSearch: string) => {
    const clean = codeToSearch.trim().toUpperCase();
    if (!clean) {
      setError('Please enter an Enquiry Reference Code (e.g., BA-ENQ-DEMO).');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/enquiries/lookup/${encodeURIComponent(clean)}`);
      const data = await res.json();
      if (!res.ok) {
        setRecord(null);
        setError(data.error || 'Reference code not found.');
      } else {
        setRecord(data);
      }
    } catch {
      setError('Unable to reach server to look up reference status.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (refParam) {
      setReferenceInput(refParam);
      lookupReference(refParam);
    } else {
      lookupReference('BA-ENQ-DEMO');
    }
  }, [refParam, lookupReference]);

  return (
    <div className="max-w-5xl mx-auto px-6 py-14 space-y-12">
      <div className="space-y-3">
        <div className="flex items-center gap-2 text-xs font-medium text-sky-400">
          <span>Client Enquiry & Quotation Tracker</span>
          <span aria-hidden="true">·</span>
          <span className="text-slate-400">Live Backend Lookup</span>
        </div>
        <h1 className="text-3xl md:text-4xl font-extrabold text-white font-display tracking-tight">
          Track Your Project Enquiry & Quotation Status
        </h1>
        <p className="text-sm md:text-base text-slate-300 max-w-2xl leading-relaxed">
          Enter the Reference Code provided when you submitted your project brief (or test with our pre-loaded demonstration code <code className="text-sky-400 font-mono">BA-ENQ-DEMO</code>) to view real-time engineering review and quotation status.
        </p>
      </div>

      {/* Search Bar */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          lookupReference(referenceInput);
        }}
        className="rounded-2xl bg-[#0B1120] border border-slate-800 p-6 flex flex-col sm:flex-row items-stretch sm:items-center gap-4"
      >
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={referenceInput}
            onChange={(e) => setReferenceInput(e.target.value)}
            placeholder="Enter Reference Code (e.g., BA-ENQ-DEMO)"
            aria-label="Enquiry Reference Code"
            className="w-full pl-11 pr-4 py-3 text-sm font-mono bg-[#060913] border border-slate-800 rounded-xl text-white focus:outline-none focus:border-sky-400"
          />
        </div>
        <button
          type="submit"
          disabled={loading}
          className="px-6 py-3 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          {loading ? 'Searching...' : 'Look Up Status'}
        </button>
      </form>

      {error && (
        <div className="p-5 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center gap-3 text-xs text-red-300">
          <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {record && (
        <div className="rounded-2xl bg-[#0B1120] border border-slate-800 p-8 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-5">
            <div>
              <p className="text-xs font-mono text-sky-400 tabular-nums">
                REFERENCE: {record.referenceCode}
              </p>
              <h2 className="text-xl font-bold text-white font-display mt-1">
                {record.serviceRequired}
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Organisation: {record.companyName}
              </p>
            </div>

            <div className="text-right">
              <span className="text-xs text-slate-400 block">Current Stage</span>
              <span className="text-sm font-semibold text-emerald-400 mt-0.5 block">
                {record.status}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div className="p-4 rounded-xl bg-[#060913] border border-slate-800">
              <span className="text-slate-400 block">Estimated Budget (RM)</span>
              <span className="text-white font-mono mt-1 block tabular-nums">
                {record.estimatedBudgetRM}
              </span>
            </div>
            <div className="p-4 rounded-xl bg-[#060913] border border-slate-800">
              <span className="text-slate-400 block">Preferred Timeline</span>
              <span className="text-white font-mono mt-1 block">
                {record.preferredTimeline}
              </span>
            </div>
            <div className="p-4 rounded-xl bg-[#060913] border border-slate-800">
              <span className="text-slate-400 block">Logged Date</span>
              <span className="text-white font-mono mt-1 block tabular-nums">
                {record.createdAt ? new Date(record.createdAt).toLocaleDateString() : '—'}
              </span>
            </div>
          </div>

          <div className="p-5 rounded-xl bg-[#060913] border border-slate-800 space-y-1.5">
            <p className="text-xs font-semibold text-slate-200">
              Engineering & Quotation Notes
            </p>
            <p className="text-xs text-slate-300 leading-relaxed">
              {record.adminNotes || 'Enquiry received and queued for engineering review.'}
            </p>
          </div>
        </div>
      )}

      <div className="rounded-xl bg-[#0B1120]/60 border border-slate-800 p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <p className="text-xs text-slate-400">
          Need to submit a new project specification or request a formal quotation?
        </p>
        <Link
          to="/contact"
          className="px-4 py-2 text-xs font-semibold text-sky-400 hover:text-sky-300 border border-slate-700 rounded-lg transition-colors whitespace-nowrap shrink-0 inline-block"
        >
          Go to Project Enquiry Form →
        </Link>
      </div>
    </div>
  );
};
