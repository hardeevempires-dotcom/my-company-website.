import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, ArrowRight, CheckCircle2, Layers, Terminal } from 'lucide-react';
import type { ProjectItem } from '../types';
import { ResilientImage } from '../components/ResilientImage';

interface ProjectDetailPageProps {
  allProjects: ProjectItem[];
}

export const ProjectDetailPage: React.FC<ProjectDetailPageProps> = ({ allProjects }) => {
  const { slug } = useParams<{ slug: string }>();
  const [activeModuleIdx, setActiveModuleIdx] = useState(0);

  const project = allProjects.find((p) => p.slug === slug) || allProjects.find((p) => p.slug === 'serviceflow') || allProjects[0];

  if (!project) {
    return (
      <div className="max-w-4xl mx-auto px-6 py-20 text-center space-y-4">
        <h1 className="text-2xl font-bold text-white font-display">Project Not Found</h1>
        <p className="text-sm text-slate-400">The requested portfolio project could not be located.</p>
        <Link
          to="/portfolio"
          className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-blue-600 rounded-lg"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Portfolio</span>
        </Link>
      </div>
    );
  }

  // Interactive simulated live preview data for ServiceFlow modules
  const serviceFlowPreviewRows = [
    {
      ticketId: 'SF-2026-1042',
      customer: 'Klang Valley HVAC Services',
      stage: 'Quotation Approved',
      technician: 'Ahmad Faiz (Lead Tech)',
      amountRM: 'RM 3,850.00',
      invoiceStatus: 'Scheduled',
    },
    {
      ticketId: 'SF-2026-1043',
      customer: 'Penang Precision Industrial',
      stage: 'Job In Progress',
      technician: 'Daniel Tan (Senior Eng)',
      amountRM: 'RM 7,200.00',
      invoiceStatus: 'Parts Allocated',
    },
    {
      ticketId: 'SF-2026-1044',
      customer: 'Metro Commercial Facilities',
      stage: 'Completed & Invoiced',
      technician: 'Siti Nurhaliza (Field Specialist)',
      amountRM: 'RM 2,450.00',
      invoiceStatus: 'Paid (INV-8821)',
    },
  ];

  const otherProjects = allProjects.filter((p) => p.id !== project.id).slice(0, 2);

  const quoteServiceTitle =
    project.category === 'Business Systems'
      ? 'Business Management Systems'
      : project.category === 'Websites'
      ? 'Website Design and Development'
      : project.category === 'Mobile Applications'
      ? 'Mobile Application Development for Android and iOS'
      : project.category === 'AI Solutions'
      ? 'AI Chatbots and AI-powered Applications'
      : 'UI/UX Design';

  return (
    <div className="max-w-7xl mx-auto px-6 py-12 space-y-16">
      {/* Back navigation */}
      <div>
        <Link
          to="/portfolio"
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Portfolio & Projects</span>
        </Link>
      </div>

      {/* Project Header */}
      <div className="space-y-5">
        <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
          <span className="text-sky-400 font-medium">{project.category}</span>
          <span aria-hidden="true">·</span>
          <span>Status: {project.status}</span>
          {project.isSampleConcept && (
            <>
              <span aria-hidden="true">·</span>
              <span className="text-amber-300">Sample Reference Concept</span>
            </>
          )}
        </div>

        <h1
          className="text-3xl md:text-5xl font-extrabold text-white font-display tracking-tight"
          style={{ textWrap: 'balance' }}
        >
          {project.title}
        </h1>

        <p className="text-lg text-slate-300 font-medium max-w-3xl">
          {project.subtitle}
        </p>

        <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-slate-400 pt-1">
          <span>Technology Stack:</span>
          {project.technologies.map((tech, idx) => (
            <React.Fragment key={tech}>
              {idx > 0 && <span aria-hidden="true">·</span>}
              <span className="text-slate-200">{tech}</span>
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* Primary Visual Showcase */}
      <div className="rounded-2xl overflow-hidden border border-slate-800 bg-[#0B1120] aspect-[16/9] max-h-[540px]">
        <ResilientImage
          src={project.imageUrl}
          alt={`${project.title} interface showcase`}
          fallbackTitle={project.title}
          fallbackSubtitle={project.subtitle}
          className="w-full h-full object-cover"
        />
      </div>

      {/* Overview, Problem Solved, Proposed Solution */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="rounded-2xl bg-[#0B1120] border border-slate-800 p-7 space-y-3">
          <p className="text-xs font-mono text-sky-400">01 / PROJECT OVERVIEW</p>
          <h2 className="text-lg font-bold text-white font-display">System Summary</h2>
          <p className="text-sm text-slate-300 leading-relaxed">{project.overview}</p>
        </div>

        <div className="rounded-2xl bg-[#0B1120] border border-slate-800 p-7 space-y-3">
          <p className="text-xs font-mono text-sky-400">02 / PROBLEM BEING SOLVED</p>
          <h2 className="text-lg font-bold text-white font-display">Operational Bottleneck</h2>
          <p className="text-sm text-slate-300 leading-relaxed">{project.problemSolved}</p>
        </div>

        <div className="rounded-2xl bg-[#0B1120] border border-slate-800 p-7 space-y-3">
          <p className="text-xs font-mono text-sky-400">03 / PROPOSED SOLUTION</p>
          <h2 className="text-lg font-bold text-white font-display">Architectural Approach</h2>
          <p className="text-sm text-slate-300 leading-relaxed">{project.proposedSolution}</p>
        </div>
      </div>

      {/* Interactive ServiceFlow Module Explorer (if project has modules) */}
      {project.modules && project.modules.length > 0 && (
        <section className="rounded-2xl bg-[#0B1120] border border-slate-800 p-8 md:p-10 space-y-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-800 pb-6">
            <div>
              <p className="text-xs font-medium text-sky-400">
                Interactive System Architecture Breakdown
              </p>
              <h2 className="text-2xl font-bold text-white font-display mt-1">
                How {project.title} Connects Every Operational Stage
              </h2>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {project.modules.map((mod, idx) => (
                <button
                  key={mod.name}
                  type="button"
                  onClick={() => setActiveModuleIdx(idx)}
                  className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    activeModuleIdx === idx
                      ? 'bg-blue-600 text-white'
                      : 'bg-[#060913] text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  {mod.name}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div className="lg:col-span-5 space-y-4">
              <h3 className="text-xl font-bold text-white font-display">
                {project.modules[activeModuleIdx].name}
              </h3>
              <p className="text-sm text-slate-300 leading-relaxed">
                {project.modules[activeModuleIdx].summary}
              </p>
              <ul className="space-y-2.5 pt-2">
                {project.modules[activeModuleIdx].capabilities.map((cap, cIdx) => (
                  <li key={cIdx} className="flex items-start gap-2.5 text-xs text-slate-300">
                    <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                    <span>{cap}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Live Tabular Data Preview illustrating how ServiceFlow tracks Tickets -> Quotes -> Jobs -> Invoices */}
            <div className="lg:col-span-7 rounded-xl bg-[#060913] border border-slate-800 p-5 space-y-4 overflow-x-auto">
              <div className="flex items-center justify-between gap-4">
                <span className="text-xs font-semibold text-slate-200">
                  ServiceFlow Live Pipeline Preview (Sample Demonstration Data)
                </span>
                <span className="text-xs font-mono text-sky-400">Currency: MYR (RM)</span>
              </div>
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400">
                    <th className="py-2.5 pr-3 font-medium">Job / Quote ID</th>
                    <th className="py-2.5 px-3 font-medium">Customer</th>
                    <th className="py-2.5 px-3 font-medium">Workflow Stage</th>
                    <th className="py-2.5 px-3 font-medium">Assigned Tech</th>
                    <th className="py-2.5 pl-3 font-medium text-right">Quotation / Invoice</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/70 font-mono tabular-nums">
                  {serviceFlowPreviewRows.map((row) => (
                    <tr key={row.ticketId} className="text-slate-300">
                      <td className="py-3 pr-3 text-sky-400">{row.ticketId}</td>
                      <td className="py-3 px-3 font-sans text-white">{row.customer}</td>
                      <td className="py-3 px-3 font-sans text-slate-300">{row.stage}</td>
                      <td className="py-3 px-3 font-sans text-slate-400">{row.technician}</td>
                      <td className="py-3 pl-3 text-right text-white">
                        {row.amountRM} · <span className="text-slate-400">{row.invoiceStatus}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      )}

      {/* Key Features & Architecture Highlights */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-7 rounded-2xl bg-[#0B1120] border border-slate-800 p-8 space-y-5">
          <div className="flex items-center gap-2 text-xs font-medium text-sky-400">
            <Layers className="w-4 h-4" />
            <span>Core Capabilities & Functional Scope</span>
          </div>
          <h2 className="text-2xl font-bold text-white font-display">Key System Features</h2>
          <ul className="space-y-3.5">
            {project.features.map((feature, idx) => (
              <li key={idx} className="flex items-start gap-3 text-sm text-slate-300 leading-relaxed">
                <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0 mt-1" />
                <span>{feature}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="lg:col-span-5 rounded-2xl bg-[#0B1120] border border-slate-800 p-8 space-y-6 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-xs font-medium text-sky-400">
              <Terminal className="w-4 h-4" />
              <span>Technical Engineering Highlights</span>
            </div>
            <h2 className="text-xl font-bold text-white font-display">
              Architecture & Reliability
            </h2>
            <ul className="space-y-3">
              {project.architectureHighlights.map((highlight, idx) => (
                <li key={idx} className="text-sm text-slate-300 leading-relaxed">
                  • {highlight}
                </li>
              ))}
            </ul>
          </div>

          <div className="pt-6 border-t border-slate-800 space-y-2">
            <p className="text-xs font-semibold text-white">Development Lifecycle</p>
            <div className="space-y-2.5 pt-1">
              {project.developmentProcess.map((step, idx) => (
                <div key={idx} className="p-3 rounded-xl bg-[#060913] border border-slate-800/80">
                  <p className="text-xs font-semibold text-sky-400">{step.phase}</p>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">{step.detail}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Call to Action for Similar Projects */}
      <div className="rounded-2xl bg-gradient-to-r from-[#0F172A] via-[#131C31] to-[#1E1B4B] border border-slate-700/80 p-8 md:p-12 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2 max-w-2xl">
          <p className="text-xs font-medium text-sky-400">
            Interested in a Similar Solution?
          </p>
          <h2 className="text-2xl md:text-3xl font-bold text-white font-display">
            Build a Custom {project.category} Platform With BUILD AURA
          </h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            Whether you want to deploy a customized version of {project.title} for your organization or architect an entirely new digital product, our team is ready to scope your requirements.
          </p>
        </div>

        <Link
          to={`/contact?service=${encodeURIComponent(quoteServiceTitle)}`}
          className="inline-flex items-center gap-2 px-6 py-3.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition-colors whitespace-nowrap shrink-0"
        >
          <span>Request a Quote for Similar System</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>

      {/* Related Portfolio Projects */}
      {otherProjects.length > 0 && (
        <div className="space-y-6 pt-6 border-t border-slate-800">
          <h3 className="text-lg font-bold text-white font-display">
            Explore Other Reference Architectures
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {otherProjects.map((other) => (
              <div
                key={other.id}
                className="p-6 rounded-2xl bg-[#0B1120] border border-slate-800 flex items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <p className="text-xs text-sky-400">{other.category}</p>
                  <p className="text-base font-bold text-white font-display">{other.title}</p>
                  <p className="text-xs text-slate-400">{other.subtitle}</p>
                </div>
                <Link
                  to={`/portfolio/${other.slug}`}
                  className="px-3.5 py-2 text-xs font-semibold text-slate-200 hover:text-white bg-slate-900 border border-slate-700 rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  Inspect →
                </Link>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
