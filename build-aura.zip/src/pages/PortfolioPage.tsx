import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Layers } from 'lucide-react';
import type { ProjectCategory, ProjectItem } from '../types';
import { ResilientImage } from '../components/ResilientImage';

interface PortfolioPageProps {
  projects: ProjectItem[];
}

const CATEGORIES: ProjectCategory[] = [
  'All',
  'Business Systems',
  'Websites',
  'Mobile Applications',
  'AI Solutions',
  'UI/UX Design',
];

export const PortfolioPage: React.FC<PortfolioPageProps> = ({ projects }) => {
  const [activeCategory, setActiveCategory] = useState<ProjectCategory>('All');

  const filteredProjects =
    activeCategory === 'All'
      ? projects
      : projects.filter((p) => p.category === activeCategory);

  return (
    <div className="max-w-7xl mx-auto px-6 py-14 space-y-16">
      {/* Header */}
      <div className="space-y-4 max-w-3xl">
        <div className="flex items-center gap-2 text-xs font-medium text-sky-400">
          <span>Portfolio & System Architectures</span>
          <span aria-hidden="true">·</span>
          <span className="text-slate-400">Flagship Systems & Sample Concepts</span>
        </div>
        <h1
          className="text-3xl md:text-5xl font-extrabold text-white font-display tracking-tight"
          style={{ textWrap: 'balance' }}
        >
          Engineered Digital Products & Reference Systems
        </h1>
        <p className="text-base md:text-lg text-slate-300 leading-relaxed">
          Explore our flagship service-management platform, <strong className="text-white font-semibold">ServiceFlow</strong>, alongside clearly labelled sample reference architectures demonstrating our capabilities across web commerce, mobile applications, AI automation, and enterprise UI/UX.
        </p>
      </div>

      {/* Category Filter Buttons */}
      <div
        role="tablist"
        aria-label="Filter projects by category"
        className="flex flex-wrap items-center gap-1.5 p-1.5 bg-[#0B1120] border border-slate-800 rounded-xl w-fit"
      >
        {CATEGORIES.map((category) => (
          <button
            key={category}
            role="tab"
            aria-selected={activeCategory === category}
            type="button"
            onClick={() => setActiveCategory(category)}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeCategory === category
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Project Grid */}
      {filteredProjects.length === 0 ? (
        <div className="rounded-2xl bg-[#0B1120] border border-slate-800 p-12 text-center space-y-3">
          <Layers className="w-8 h-8 text-slate-500 mx-auto" />
          <p className="text-base font-semibold text-white">No projects in this category yet</p>
          <p className="text-xs text-slate-400">
            Select “All” to view our flagship ServiceFlow platform and sample reference architectures.
          </p>
        </div>
      ) : (
        <div className="space-y-10">
          {filteredProjects.map((project) => (
            <article
              key={project.id}
              className={`rounded-2xl bg-[#0B1120] border overflow-hidden transition-colors ${
                project.isFlagship
                  ? 'border-sky-500/50'
                  : 'border-slate-800/90 hover:border-slate-700'
              }`}
            >
              <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
                {/* Image Column */}
                <div className="lg:col-span-5 bg-[#060913] border-b lg:border-b-0 lg:border-r border-slate-800 min-h-[260px]">
                  <ResilientImage
                    src={project.imageUrl}
                    alt={project.title}
                    fallbackTitle={project.title}
                    fallbackSubtitle={project.category}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Details Column */}
                <div className="lg:col-span-7 p-7 md:p-9 flex flex-col justify-between space-y-6">
                  <div className="space-y-3">
                    {/* Clean unboxed metadata */}
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
                      <span className="text-sky-400 font-medium">{project.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>{project.status}</span>
                      {project.isSampleConcept && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="text-amber-300/90">Sample Reference Concept</span>
                        </>
                      )}
                    </div>

                    <h2 className="text-2xl font-bold text-white font-display tracking-tight">
                      {project.title}
                    </h2>

                    <p className="text-xs font-medium text-slate-400">
                      {project.subtitle}
                    </p>

                    <p className="text-sm text-slate-300 leading-relaxed pt-1">
                      {project.overview}
                    </p>

                    <div className="pt-2 space-y-1.5">
                      <p className="text-xs font-semibold text-slate-200">Core Capabilities</p>
                      <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-400">
                        {project.features.slice(0, 4).map((feat, idx) => (
                          <li key={idx} className="leading-relaxed">
                            • {feat.split(':')[0]}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="pt-5 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-4">
                    <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-slate-400">
                      {project.technologies.map((tech, idx) => (
                        <React.Fragment key={tech}>
                          {idx > 0 && <span aria-hidden="true">·</span>}
                          <span>{tech}</span>
                        </React.Fragment>
                      ))}
                    </div>

                    <div className="flex items-center gap-3">
                      <Link
                        to={`/portfolio/${project.slug}`}
                        className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition-colors whitespace-nowrap shrink-0"
                      >
                        <span>View Full Case Study</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}

      {/* Transparency Note */}
      <div className="rounded-xl bg-[#0B1120]/70 border border-slate-800/80 p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <p className="text-xs font-semibold text-slate-200">
            Portfolio Transparency & Intellectual Property Notice
          </p>
          <p className="text-xs text-slate-400 leading-relaxed max-w-3xl">
            In accordance with our commitment to honesty and client confidentiality, <strong className="text-slate-200">ServiceFlow</strong> is featured as our flagship service-management system architecture, while additional domain cards are clearly labelled as sample reference architectures illustrating how BUILD AURA engineers solutions across industries.
          </p>
        </div>
        <Link
          to="/contact"
          className="px-4 py-2.5 text-xs font-semibold text-sky-400 hover:text-sky-300 border border-slate-700 rounded-lg transition-colors whitespace-nowrap shrink-0 inline-block"
        >
          Request a Custom Demo →
        </Link>
      </div>
    </div>
  );
};
