export type PageRoute =
  | 'home'
  | 'services'
  | 'portfolio'
  | 'project-detail'
  | 'process'
  | 'about'
  | 'contact'
  | 'portal'
  | 'admin'
  | 'privacy'
  | 'terms';

export type ProjectCategory =
  | 'All'
  | 'Business Systems'
  | 'Websites'
  | 'Mobile Applications'
  | 'AI Solutions'
  | 'UI/UX Design';

export interface ServiceItem {
  id: string;
  index: string;
  title: string;
  category: string;
  shortDescription: string;
  fullDescription: string;
  iconName: string;
  benefits: string[];
  deliverables: string[];
  typicalTimeline: string;
  startingEstimateRM: string;
}

export interface ProjectModule {
  name: string;
  summary: string;
  capabilities: string[];
}

export interface ProjectItem {
  id: string;
  slug: string;
  title: string;
  subtitle: string;
  category: Exclude<ProjectCategory, 'All'>;
  isFlagship?: boolean;
  isSampleConcept?: boolean;
  status: 'Active Production Architecture' | 'In Development' | 'Sample Reference Architecture';
  overview: string;
  problemSolved: string;
  proposedSolution: string;
  features: string[];
  modules?: ProjectModule[];
  technologies: string[];
  imageUrl: string;
  secondaryImageUrl?: string;
  developmentProcess: {
    phase: string;
    detail: string;
  }[];
  architectureHighlights: string[];
}

export interface ProcessPhase {
  step: string;
  title: string;
  durationNote: string;
  summary: string;
  activities: string[];
  deliverables: string[];
}

export interface EnquirySubmission {
  id: string;
  referenceCode: string;
  fullName: string;
  email: string;
  phone: string;
  companyName: string;
  serviceRequired: string;
  projectDescription: string;
  estimatedBudgetRM: string;
  preferredTimeline: string;
  attachmentName?: string;
  attachmentSize?: number;
  status: 'Received' | 'Under Review' | 'Quotation Prepared' | 'Archived';
  adminNotes?: string;
  createdAt: string;
}

export interface SiteSettings {
  companyName: string;
  tagline: string;
  whatsappNumber: string;
  contactEmail: string;
  businessHours: string;
  locationNote: string;
  acceptingNewProjects: boolean;
}
