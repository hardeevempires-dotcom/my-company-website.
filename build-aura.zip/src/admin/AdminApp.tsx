import React, { useState, useEffect, useMemo } from 'react';
import {
  Lock,
  LogOut,
  ExternalLink,
  Search,
  CheckCircle2,
  AlertCircle,
  Trash2,
  Save,
  MessageSquare,
  FileText,
  Settings,
  Layers,
  BarChart3,
  Mail,
  Clock,
  MapPin,
  RefreshCw,
  Plus,
} from 'lucide-react';
import type { EnquirySubmission, ProjectItem, ServiceItem, SiteSettings } from '../types';

export const AdminApp: React.FC = () => {
  const [token, setToken] = useState<string | null>(() => {
    return sessionStorage.getItem('buildaura_admin_token');
  });
  const [passcode, setPasscode] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Admin Data State
  const [activeTab, setActiveTab] = useState<'metrics' | 'enquiries' | 'projects' | 'settings'>('enquiries');
  const [enquiries, setEnquiries] = useState<EnquirySubmission[]>([]);
  const [projects, setProjects] = useState<ProjectItem[]>([]);
  const [services, setServices] = useState<ServiceItem[]>([]);
  const [settingsForm, setSettingsForm] = useState<SiteSettings | null>(null);
  const [statusMessage, setStatusMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Enquiry filters
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [selectedEnquiry, setSelectedEnquiry] = useState<EnquirySubmission | null>(null);

  // New project modal state
  const [showAddProjectModal, setShowAddProjectModal] = useState(false);
  const [newProjectTitle, setNewProjectTitle] = useState('');
  const [newProjectSlug, setNewProjectSlug] = useState('');
  const [newProjectSubtitle, setNewProjectSubtitle] = useState('');
  const [newProjectCategory, setNewProjectCategory] = useState<'Business Systems' | 'Websites' | 'Mobile Applications' | 'AI Solutions' | 'UI/UX Design'>('Business Systems');
  const [newProjectOverview, setNewProjectOverview] = useState('');

  const fetchAdminData = async (authToken: string) => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/verify', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${authToken}`,
        },
      });
      const data = await res.json();
      if (!res.ok) {
        setAuthError(data.error || 'Authentication rejected.');
        setToken(null);
        sessionStorage.removeItem('buildaura_admin_token');
        setLoading(false);
        return false;
      }
      setEnquiries(data.enquiries || []);
      setProjects(data.projects || []);
      setServices(data.services || []);
      setSettingsForm(data.settings || null);
      setLoading(false);
      return true;
    } catch {
      setAuthError('Unable to connect to backend server.');
      setLoading(false);
      return false;
    }
  };

  useEffect(() => {
    if (token) {
      fetchAdminData(token);
    }
  }, [token]);

  const showNotification = (text: string, type: 'success' | 'error' = 'success') => {
    setStatusMessage({ text, type });
    setTimeout(() => setStatusMessage(null), 4000);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    const cleanPass = passcode.trim();
    if (!cleanPass) {
      setAuthError('Please enter administrator passcode.');
      return;
    }
    const success = await fetchAdminData(cleanPass);
    if (success) {
      setToken(cleanPass);
      sessionStorage.setItem('buildaura_admin_token', cleanPass);
      setPasscode('');
    }
  };

  const handleLogout = () => {
    setToken(null);
    sessionStorage.removeItem('buildaura_admin_token');
  };

  const handleUpdateEnquiry = async (
    id: string,
    status: EnquirySubmission['status'],
    adminNotes: string
  ) => {
    if (!token) return;
    try {
      const res = await fetch(`/api/admin/enquiries/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status, adminNotes }),
      });
      const data = await res.json();
      if (res.ok && data.enquiry) {
        setEnquiries((prev) => prev.map((e) => (e.id === id ? data.enquiry : e)));
        if (selectedEnquiry?.id === id) {
          setSelectedEnquiry(data.enquiry);
        }
        showNotification(`Updated enquiry status to "${status}"`);
      } else {
        showNotification(data.error || 'Failed to update enquiry', 'error');
      }
    } catch {
      showNotification('Network error updating enquiry', 'error');
    }
  };

  const handleDeleteEnquiry = async (id: string) => {
    if (!token) return;
    if (!window.confirm('Are you sure you want to delete this enquiry record?')) return;
    try {
      const res = await fetch(`/api/admin/enquiries/${id}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      if (res.ok) {
        setEnquiries((prev) => prev.filter((e) => e.id !== id));
        if (selectedEnquiry?.id === id) setSelectedEnquiry(null);
        showNotification('Enquiry deleted successfully.');
      }
    } catch {
      showNotification('Failed to delete enquiry', 'error');
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !settingsForm) return;
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(settingsForm),
      });
      const data = await res.json();
      if (res.ok && data.settings) {
        setSettingsForm(data.settings);
        showNotification('Site contact & WhatsApp configuration successfully synced to main website!');
      } else {
        showNotification(data.error || 'Failed to save settings', 'error');
      }
    } catch {
      showNotification('Error connecting to backend settings endpoint', 'error');
    }
  };

  const handleAddProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    if (!newProjectTitle.trim() || !newProjectSlug.trim()) {
      showNotification('Title and URL slug are required.', 'error');
      return;
    }
    const cleanSlug = newProjectSlug.trim().toLowerCase().replace(/[^a-z0-9-]/g, '-');
    const newProject: ProjectItem = {
      id: `proj-${Date.now()}`,
      slug: cleanSlug,
      title: newProjectTitle.trim(),
      subtitle: newProjectSubtitle.trim() || 'Custom Engineered Digital Solution',
      category: newProjectCategory,
      isFlagship: false,
      isSampleConcept: true,
      status: 'In Development',
      overview: newProjectOverview.trim() || 'Engineered software platform by BUILD AURA.',
      problemSolved: 'Streamlines operational complexity and manual administrative overhead.',
      proposedSolution: 'Modular full-stack application built with scalable architecture.',
      features: ['Automated state management', 'Role-based access controls', 'Real-time reporting'],
      technologies: ['React', 'TypeScript', 'Tailwind CSS', 'Node.js', 'PostgreSQL'],
      imageUrl: '/src/assets/images/hero_software_platform_1793148713914.jpg',
      developmentProcess: [
        { phase: '01. Architecture', detail: 'Technical specification and database planning.' },
        { phase: '02. Engineering', detail: 'Component design and API implementation.' },
      ],
      architectureHighlights: ['Server-side authorization', 'Responsive multi-device layout'],
    };

    try {
      const res = await fetch('/api/admin/projects', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(newProject),
      });
      const data = await res.json();
      if (res.ok && data.projects) {
        setProjects(data.projects);
        setShowAddProjectModal(false);
        setNewProjectTitle('');
        setNewProjectSlug('');
        setNewProjectSubtitle('');
        setNewProjectOverview('');
        showNotification(`Project "${newProject.title}" published to portfolio!`);
      }
    } catch {
      showNotification('Failed to create new project.', 'error');
    }
  };

  // Filtered enquiries
  const filteredEnquiries = useMemo(() => {
    return enquiries.filter((enq) => {
      const matchesStatus = statusFilter === 'All' || enq.status === statusFilter;
      const q = searchQuery.toLowerCase();
      const matchesSearch =
        !q ||
        enq.fullName.toLowerCase().includes(q) ||
        enq.companyName.toLowerCase().includes(q) ||
        enq.email.toLowerCase().includes(q) ||
        enq.referenceCode.toLowerCase().includes(q) ||
        enq.serviceRequired.toLowerCase().includes(q);
      return matchesStatus && matchesSearch;
    });
  }, [enquiries, statusFilter, searchQuery]);

  // Statistics
  const stats = useMemo(() => {
    const total = enquiries.length;
    const received = enquiries.filter((e) => e.status === 'Received').length;
    const underReview = enquiries.filter((e) => e.status === 'Under Review').length;
    const quotationPrepared = enquiries.filter((e) => e.status === 'Quotation Prepared').length;
    return { total, received, underReview, quotationPrepared };
  }, [enquiries]);

  // If not authenticated, render the dedicated admin login portal
  if (!token) {
    return (
      <div className="min-h-screen bg-[#04070F] text-slate-100 flex flex-col justify-center items-center px-4 py-12">
        <div className="w-full max-w-md space-y-6">
          <div className="text-center space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-sky-400 mx-auto">
              <Lock className="w-6 h-6" />
            </div>
            <h1 className="text-2xl font-extrabold text-white font-display tracking-tight">
              BUILD AURA Command Center
            </h1>
            <p className="text-xs text-slate-400">
              Dedicated Administrative Operations & Lead Engine
            </p>
          </div>

          <form
            onSubmit={handleLogin}
            className="rounded-2xl bg-[#0B1120] border border-slate-800 p-8 space-y-5 shadow-2xl"
          >
            {authError && (
              <div className="p-3.5 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center gap-2.5 text-xs text-red-300">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                <span>{authError}</span>
              </div>
            )}

            <div className="space-y-2">
              <label htmlFor="admin_pass" className="block text-xs font-semibold text-slate-200">
                Administrator Security Passcode
              </label>
              <input
                id="admin_pass"
                type="password"
                required
                value={passcode}
                onChange={(e) => setPasscode(e.target.value)}
                placeholder="Enter passcode..."
                className="w-full px-4 py-3 text-sm bg-[#060913] border border-slate-800 rounded-xl text-white placeholder:text-slate-600 focus:outline-none focus:border-sky-400 font-mono"
              />
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                type="submit"
                disabled={loading}
                className="flex-1 py-3 px-4 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 disabled:opacity-50 rounded-xl transition-colors cursor-pointer"
              >
                {loading ? 'Authenticating...' : 'Sign In to Operations'}
              </button>
              <button
                type="button"
                onClick={() => setPasscode('buildaura-admin-2026')}
                className="py-3 px-3 text-xs font-mono text-sky-400 hover:text-sky-300 border border-slate-800 hover:bg-slate-900 rounded-xl cursor-pointer"
                title="Fill local development passcode"
              >
                Fill Default
              </button>
            </div>

            <div className="pt-2 text-center">
              <a
                href="/"
                className="text-xs text-slate-500 hover:text-slate-400 transition-colors"
              >
                ← Return to Public Website
              </a>
            </div>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050811] text-slate-100 flex flex-col">
      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-40 bg-[#090E1A]/95 backdrop-blur-md border-b border-slate-800 px-6 py-3.5">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-sky-400 font-bold text-xs">
              BA
            </div>
            <div>
              <span className="text-sm font-extrabold text-white tracking-tight font-display">
                BUILD AURA <span className="text-sky-400 font-normal">Command Center</span>
              </span>
              <span className="hidden sm:inline-block text-[11px] text-slate-400 ml-2">
                Operations & Lead Portal
              </span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {statusMessage && (
              <div
                className={`hidden md:flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium ${
                  statusMessage.type === 'success'
                    ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30'
                    : 'bg-red-500/10 text-red-300 border border-red-500/30'
                }`}
              >
                {statusMessage.type === 'success' ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <AlertCircle className="w-3.5 h-3.5 text-red-400" />
                )}
                <span>{statusMessage.text}</span>
              </div>
            )}

            {/* Direct link to preview main public website */}
            <a
              href="/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-900 border border-slate-700/80 rounded-lg transition-colors"
            >
              <span>View Public Website</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>

            <button
              type="button"
              onClick={handleLogout}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-400 hover:text-red-400 border border-slate-800 hover:border-red-500/40 rounded-lg transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Log Out</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Administrative Container */}
      <div className="max-w-7xl mx-auto w-full px-6 py-8 flex-1 space-y-8">
        {/* Navigation Tabs */}
        <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-4">
          <button
            type="button"
            onClick={() => setActiveTab('enquiries')}
            className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              activeTab === 'enquiries'
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Project Enquiries ({enquiries.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('metrics')}
            className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              activeTab === 'metrics'
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>Pipeline Metrics</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('projects')}
            className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              activeTab === 'projects'
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Portfolio Systems ({projects.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('settings')}
            className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              activeTab === 'settings'
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>Site & WhatsApp Settings</span>
          </button>

          <button
            type="button"
            onClick={() => token && fetchAdminData(token)}
            className="ml-auto p-2 text-slate-400 hover:text-white border border-slate-800 rounded-lg hover:bg-slate-900 cursor-pointer"
            title="Refresh data"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* 1. TAB: ENQUIRIES & LEADS */}
        {activeTab === 'enquiries' && (
          <div className="space-y-6">
            {/* Filter & Search Bar */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
              <div className="relative flex-1 max-w-md">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search by client, company, email, or code..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 text-xs bg-[#0B1120] border border-slate-800 rounded-xl text-white focus:outline-none focus:border-sky-400"
                />
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400">Status:</span>
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="px-3 py-1.5 text-xs bg-[#0B1120] border border-slate-800 rounded-lg text-white"
                >
                  <option value="All">All Statuses ({enquiries.length})</option>
                  <option value="Received">Received ({stats.received})</option>
                  <option value="Under Review">Under Review ({stats.underReview})</option>
                  <option value="Quotation Prepared">Quotation Prepared ({stats.quotationPrepared})</option>
                  <option value="Archived">Archived</option>
                </select>
              </div>
            </div>

            {/* Enquiries Grid / List */}
            {filteredEnquiries.length === 0 ? (
              <div className="p-12 text-center rounded-2xl bg-[#0B1120] border border-slate-800 space-y-2">
                <FileText className="w-8 h-8 text-slate-500 mx-auto" />
                <p className="text-sm font-semibold text-white">No enquiries match your search</p>
                <p className="text-xs text-slate-400">Try adjusting your keyword or status filter.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {filteredEnquiries.map((enq) => (
                  <div
                    key={enq.id}
                    className="rounded-2xl bg-[#0B1120] border border-slate-800 p-6 space-y-4 hover:border-slate-700 transition-colors"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-800/80 pb-4">
                      <div>
                        <div className="flex items-center gap-2 text-xs font-mono text-sky-400 tabular-nums">
                          <span>{enq.referenceCode}</span>
                          <span aria-hidden="true">·</span>
                          <span className="text-slate-400">
                            {new Date(enq.createdAt).toLocaleString()}
                          </span>
                        </div>
                        <h3 className="text-base font-bold text-white font-display mt-1">
                          {enq.fullName} — <span className="text-slate-300 font-normal">{enq.companyName}</span>
                        </h3>
                        <p className="text-xs text-slate-400 mt-0.5 font-mono">
                          {enq.email} · {enq.phone}
                        </p>
                      </div>

                      <div className="flex items-center gap-3">
                        <select
                          value={enq.status}
                          onChange={(e) =>
                            handleUpdateEnquiry(
                              enq.id,
                              e.target.value as EnquirySubmission['status'],
                              enq.adminNotes || ''
                            )
                          }
                          className="px-3 py-1.5 text-xs font-semibold bg-[#060913] border border-slate-700 rounded-lg text-white"
                        >
                          <option value="Received">Received</option>
                          <option value="Under Review">Under Review</option>
                          <option value="Quotation Prepared">Quotation Prepared</option>
                          <option value="Archived">Archived</option>
                        </select>

                        <button
                          type="button"
                          onClick={() => handleDeleteEnquiry(enq.id)}
                          className="p-2 text-slate-400 hover:text-red-400 rounded-lg border border-slate-800 hover:border-red-500/40 cursor-pointer"
                          title="Delete enquiry"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                      <div>
                        <span className="text-slate-400 block">Service Required</span>
                        <span className="text-white font-medium block mt-0.5">{enq.serviceRequired}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">Estimated Budget (RM)</span>
                        <span className="text-sky-400 font-mono tabular-nums block mt-0.5">{enq.estimatedBudgetRM}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">Timeline</span>
                        <span className="text-slate-200 block mt-0.5">{enq.preferredTimeline}</span>
                      </div>
                    </div>

                    <div className="p-4 rounded-xl bg-[#060913] border border-slate-800/80 text-xs text-slate-300 leading-relaxed">
                      <p className="font-semibold text-slate-200 mb-1">Project Brief:</p>
                      {enq.projectDescription}
                      {enq.attachmentName && (
                        <p className="text-sky-400 font-mono mt-2 flex items-center gap-1.5">
                          <FileText className="w-3.5 h-3.5" />
                          <span>Attachment: {enq.attachmentName}</span>
                        </p>
                      )}
                    </div>

                    {/* Quotation & Review Notes */}
                    <div className="space-y-1.5">
                      <label className="block text-[11px] font-semibold text-slate-400">
                        Engineering Review & Quotation Notes (Synced to Client Tracker):
                      </label>
                      <input
                        type="text"
                        defaultValue={enq.adminNotes || ''}
                        placeholder="Add review notes, quotation status, or milestone details..."
                        onBlur={(e) =>
                          handleUpdateEnquiry(enq.id, enq.status, e.target.value)
                        }
                        className="w-full px-3.5 py-2 text-xs bg-[#060913] border border-slate-800 rounded-lg text-slate-200 focus:outline-none focus:border-sky-400"
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* 2. TAB: METRICS & PIPELINE */}
        {activeTab === 'metrics' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              <div className="p-6 rounded-2xl bg-[#0B1120] border border-slate-800 space-y-2">
                <span className="text-xs font-mono text-slate-400">TOTAL ENQUIRIES</span>
                <p className="text-3xl font-extrabold text-white font-display tabular-nums">
                  {stats.total}
                </p>
                <p className="text-xs text-slate-400">All recorded client briefs</p>
              </div>

              <div className="p-6 rounded-2xl bg-[#0B1120] border border-slate-800 space-y-2">
                <span className="text-xs font-mono text-sky-400">NEW / RECEIVED</span>
                <p className="text-3xl font-extrabold text-sky-400 font-display tabular-nums">
                  {stats.received}
                </p>
                <p className="text-xs text-slate-400">Awaiting initial engineering review</p>
              </div>

              <div className="p-6 rounded-2xl bg-[#0B1120] border border-slate-800 space-y-2">
                <span className="text-xs font-mono text-amber-400">UNDER REVIEW</span>
                <p className="text-3xl font-extrabold text-amber-400 font-display tabular-nums">
                  {stats.underReview}
                </p>
                <p className="text-xs text-slate-400">In architectural scoping</p>
              </div>

              <div className="p-6 rounded-2xl bg-[#0B1120] border border-slate-800 space-y-2">
                <span className="text-xs font-mono text-emerald-400">QUOTATION PREPARED</span>
                <p className="text-3xl font-extrabold text-emerald-400 font-display tabular-nums">
                  {stats.quotationPrepared}
                </p>
                <p className="text-xs text-slate-400">Itemised RM quotes delivered</p>
              </div>
            </div>

            <div className="p-7 rounded-2xl bg-[#0B1120] border border-slate-800 space-y-4">
              <h2 className="text-base font-bold text-white font-display">
                Service Demand Distribution
              </h2>
              <div className="space-y-3">
                {services.slice(0, 6).map((service) => {
                  const count = enquiries.filter(
                    (e) => e.serviceRequired.toLowerCase() === service.title.toLowerCase()
                  ).length;
                  const pct = stats.total > 0 ? Math.round((count / stats.total) * 100) : 0;
                  return (
                    <div key={service.id} className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-300">{service.title}</span>
                        <span className="text-slate-400 font-mono tabular-nums">
                          {count} ({pct}%)
                        </span>
                      </div>
                      <div className="h-2 w-full rounded-full bg-[#060913] overflow-hidden">
                        <div
                          className="h-full bg-blue-600 rounded-full transition-all"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* 3. TAB: PORTFOLIO & ARCHITECTURES */}
        {activeTab === 'projects' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-white font-display">
                  Portfolio Projects & Architecture Showcase
                </h2>
                <p className="text-xs text-slate-400">
                  Manage the showcase items visible on the public /portfolio page.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowAddProjectModal(true)}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition-colors cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add Portfolio Project</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {projects.map((proj) => (
                <div
                  key={proj.id}
                  className="rounded-2xl bg-[#0B1120] border border-slate-800 p-6 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono text-sky-400">{proj.category}</span>
                    <span className="text-[11px] font-mono text-slate-400">
                      {proj.isFlagship ? '★ Flagship System' : proj.status}
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-white font-display">{proj.title}</h3>
                  <p className="text-xs text-slate-400">{proj.subtitle}</p>
                  <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">{proj.overview}</p>
                  <div className="pt-2 text-xs font-mono text-slate-500">
                    URL Slug: <span className="text-slate-300">/portfolio/{proj.slug}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Add Project Modal */}
            {showAddProjectModal && (
              <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
                <form
                  onSubmit={handleAddProject}
                  className="w-full max-w-lg rounded-2xl bg-[#0B1120] border border-slate-700 p-6 space-y-4 shadow-2xl"
                >
                  <h3 className="text-base font-bold text-white font-display">Add Portfolio Project</h3>
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300">Project Title</label>
                    <input
                      type="text"
                      required
                      value={newProjectTitle}
                      onChange={(e) => {
                        setNewProjectTitle(e.target.value);
                        if (!newProjectSlug) {
                          setNewProjectSlug(e.target.value.toLowerCase().replace(/\s+/g, '-'));
                        }
                      }}
                      placeholder="e.g., FleetTrack Logistics Management"
                      className="w-full px-3 py-2 text-xs bg-[#060913] border border-slate-800 rounded-lg text-white"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300">URL Slug</label>
                    <input
                      type="text"
                      required
                      value={newProjectSlug}
                      onChange={(e) => setNewProjectSlug(e.target.value)}
                      placeholder="e.g., fleettrack-logistics"
                      className="w-full px-3 py-2 text-xs font-mono bg-[#060913] border border-slate-800 rounded-lg text-white"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300">Category</label>
                    <select
                      value={newProjectCategory}
                      onChange={(e) => setNewProjectCategory(e.target.value as any)}
                      className="w-full px-3 py-2 text-xs bg-[#060913] border border-slate-800 rounded-lg text-white"
                    >
                      <option value="Business Systems">Business Systems</option>
                      <option value="Websites">Websites</option>
                      <option value="Mobile Applications">Mobile Applications</option>
                      <option value="AI Solutions">AI Solutions</option>
                      <option value="UI/UX Design">UI/UX Design</option>
                    </select>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300">Subtitle / Tagline</label>
                    <input
                      type="text"
                      value={newProjectSubtitle}
                      onChange={(e) => setNewProjectSubtitle(e.target.value)}
                      placeholder="e.g., Real-time Fleet Telemetry & Maintenance Portal"
                      className="w-full px-3 py-2 text-xs bg-[#060913] border border-slate-800 rounded-lg text-white"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300">Overview Description</label>
                    <textarea
                      rows={3}
                      value={newProjectOverview}
                      onChange={(e) => setNewProjectOverview(e.target.value)}
                      placeholder="Describe what the system solves..."
                      className="w-full px-3 py-2 text-xs bg-[#060913] border border-slate-800 rounded-lg text-white"
                    />
                  </div>
                  <div className="flex items-center justify-end gap-3 pt-3">
                    <button
                      type="button"
                      onClick={() => setShowAddProjectModal(false)}
                      className="px-4 py-2 text-xs text-slate-400 hover:text-white"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg"
                    >
                      Save & Publish
                    </button>
                  </div>
                </form>
              </div>
            )}
          </div>
        )}

        {/* 4. TAB: SITE & WHATSAPP SETTINGS */}
        {activeTab === 'settings' && settingsForm && (
          <form
            onSubmit={handleSaveSettings}
            className="rounded-2xl bg-[#0B1120] border border-slate-800 p-8 space-y-6 max-w-3xl"
          >
            <div>
              <h2 className="text-lg font-bold text-white font-display">
                Company & Contact Configuration
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Changes saved here link directly to the public BUILD AURA website in real time.
              </p>
            </div>

            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                  <span>WhatsApp Number (International digits without '+', e.g. 60123456789)</span>
                </label>
                <input
                  type="text"
                  value={settingsForm.whatsappNumber}
                  onChange={(e) =>
                    setSettingsForm({ ...settingsForm, whatsappNumber: e.target.value })
                  }
                  placeholder="e.g., 60123456789"
                  className="w-full px-4 py-2.5 text-xs font-mono bg-[#060913] border border-slate-800 rounded-xl text-white focus:outline-none focus:border-sky-400"
                />
                <p className="text-[11px] text-slate-500">
                  When set, the WhatsApp contact button on the website will open a direct chat. If left empty, it safely prompts without broken links.
                </p>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-sky-400" />
                  <span>Public Enquiries Email Address</span>
                </label>
                <input
                  type="email"
                  value={settingsForm.contactEmail}
                  onChange={(e) =>
                    setSettingsForm({ ...settingsForm, contactEmail: e.target.value })
                  }
                  className="w-full px-4 py-2.5 text-xs font-mono bg-[#060913] border border-slate-800 rounded-xl text-white focus:outline-none focus:border-sky-400"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span>Operating Hours</span>
                </label>
                <input
                  type="text"
                  value={settingsForm.businessHours}
                  onChange={(e) =>
                    setSettingsForm({ ...settingsForm, businessHours: e.target.value })
                  }
                  className="w-full px-4 py-2.5 text-xs bg-[#060913] border border-slate-800 rounded-xl text-white focus:outline-none focus:border-sky-400"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  <span>Coverage & Location Note</span>
                </label>
                <input
                  type="text"
                  value={settingsForm.locationNote}
                  onChange={(e) =>
                    setSettingsForm({ ...settingsForm, locationNote: e.target.value })
                  }
                  className="w-full px-4 py-2.5 text-xs bg-[#060913] border border-slate-800 rounded-xl text-white focus:outline-none focus:border-sky-400"
                />
              </div>

              <div className="pt-2 flex items-center gap-3">
                <input
                  id="acceptingProjects"
                  type="checkbox"
                  checked={settingsForm.acceptingNewProjects}
                  onChange={(e) =>
                    setSettingsForm({ ...settingsForm, acceptingNewProjects: e.target.checked })
                  }
                  className="w-4 h-4 rounded text-blue-600 bg-[#060913] border-slate-800"
                />
                <label htmlFor="acceptingProjects" className="text-xs font-semibold text-slate-300">
                  Accepting new project enquiries for current quarter
                </label>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 flex justify-end">
              <button
                type="submit"
                className="inline-flex items-center gap-2 px-6 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition-colors cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Save & Sync to Live Website</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
