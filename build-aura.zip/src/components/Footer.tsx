import React from 'react';
import { Link } from 'react-router-dom';
import type { SiteSettings } from '../types';

interface FooterProps {
  settings: SiteSettings;
}

export const Footer: React.FC<FooterProps> = ({ settings }) => {
  return (
    <footer className="bg-[#04070F] border-t border-slate-800/80 text-slate-400">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 pb-12 border-b border-slate-800/80">
          {/* Brand Identity Lockup & Tagline */}
          <div className="md:col-span-5 space-y-4">
            <Link to="/" className="flex items-center gap-3 w-fit">
              <svg
                className="w-8 h-8 shrink-0"
                viewBox="0 0 36 36"
                fill="none"
                aria-hidden="true"
              >
                <rect width="36" height="36" rx="8" fill="#0F172A" stroke="#1E293B" />
                <path
                  d="M18 6L29 27H23.5L18 16L12.5 27H7L18 6Z"
                  fill="url(#auraFooterGrad)"
                />
                <path d="M14.5 23H21.5L23.5 27H12.5L14.5 23Z" fill="#38BDF8" />
                <defs>
                  <linearGradient
                    id="auraFooterGrad"
                    x1="7"
                    y1="6"
                    x2="29"
                    y2="27"
                    gradientUnits="userSpaceOnUse"
                  >
                    <stop stopColor="#38BDF8" />
                    <stop offset="0.5" stopColor="#3B82F6" />
                    <stop offset="1" stopColor="#A855F7" />
                  </linearGradient>
                </defs>
              </svg>
              <div>
                <span className="text-lg font-extrabold tracking-tight text-white block leading-none">
                  {settings.companyName}
                </span>
                <span className="text-xs text-sky-400 font-medium tracking-wide mt-1 block">
                  {settings.tagline}
                </span>
              </div>
            </Link>

            <p className="text-sm text-slate-400 max-w-md leading-relaxed">
              BUILD AURA designs and develops custom websites, mobile applications, enterprise management systems, and AI-powered software solutions built for clarity, security, and measurable business impact.
            </p>

            <div className="text-xs text-slate-500 space-y-1 pt-1">
              <p>{settings.locationNote}</p>
              <p>{settings.businessHours}</p>
            </div>
          </div>

          {/* Core Navigation */}
          <div className="md:col-span-2 space-y-3">
            <h3 className="text-xs font-semibold text-slate-200 tracking-wide">
              Navigation
            </h3>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link to="/" className="hover:text-white transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-white transition-colors">
                  Services
                </Link>
              </li>
              <li>
                <Link to="/portfolio" className="hover:text-white transition-colors">
                  Portfolio & Work
                </Link>
              </li>
              <li>
                <Link to="/process" className="hover:text-white transition-colors">
                  Our Process
                </Link>
              </li>
              <li>
                <Link to="/about" className="hover:text-white transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-white transition-colors">
                  Project Enquiry
                </Link>
              </li>
            </ul>
          </div>

          {/* Flagship & Capabilities */}
          <div className="md:col-span-3 space-y-3">
            <h3 className="text-xs font-semibold text-slate-200 tracking-wide">
              Featured Solutions
            </h3>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link
                  to="/portfolio/serviceflow"
                  className="text-sky-400 hover:text-sky-300 transition-colors block text-left"
                >
                  ServiceFlow Management System
                </Link>
              </li>
              <li>
                <Link
                  to="/services"
                  className="hover:text-white transition-colors block text-left"
                >
                  Web & E-Commerce Platforms
                </Link>
              </li>
              <li>
                <Link
                  to="/services"
                  className="hover:text-white transition-colors block text-left"
                >
                  Android & iOS Mobile Apps
                </Link>
              </li>
              <li>
                <Link
                  to="/services"
                  className="hover:text-white transition-colors block text-left"
                >
                  Custom Enterprise Software
                </Link>
              </li>
              <li>
                <Link
                  to="/services"
                  className="hover:text-white transition-colors block text-left"
                >
                  AI Solutions & Automation
                </Link>
              </li>
            </ul>
          </div>

          {/* Client & Governance Links */}
          <div className="md:col-span-2 space-y-3">
            <h3 className="text-xs font-semibold text-slate-200 tracking-wide">
              Client & Governance
            </h3>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link
                  to="/portal"
                  className="hover:text-white transition-colors block text-left"
                >
                  Enquiry Tracker
                </Link>
              </li>
              <li>
                <Link
                  to="/privacy"
                  className="hover:text-white transition-colors block text-left"
                >
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link
                  to="/terms"
                  className="hover:text-white transition-colors block text-left"
                >
                  Terms of Service
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Copyright & Action Row */}
        <div className="pt-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-slate-500">
          <p>
            © {new Date().getFullYear()} {settings.companyName}. All rights reserved. Multi-page enterprise architecture.
          </p>
          <div className="flex items-center gap-4">
            <span>Direct Enquiries: {settings.contactEmail}</span>
            <span aria-hidden="true">·</span>
            <Link
              to="/contact"
              className="text-sky-400 hover:text-sky-300 font-medium transition-colors"
            >
              Discuss Your Idea →
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};
