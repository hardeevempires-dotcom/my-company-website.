import React, { useState } from 'react';
import { Layers } from 'lucide-react';

interface ResilientImageProps {
  src: string;
  alt: string;
  fallbackTitle?: string;
  fallbackSubtitle?: string;
  className?: string;
}

export const ResilientImage: React.FC<ResilientImageProps> = ({
  src,
  alt,
  fallbackTitle = 'BUILD AURA System Preview',
  fallbackSubtitle = 'Enterprise Software Architecture',
  className = 'w-full h-full object-cover',
}) => {
  const [hasError, setHasError] = useState(false);

  if (hasError || !src) {
    return (
      <div
        className={`flex flex-col items-center justify-center p-8 text-center bg-gradient-to-br from-[#0F172A] via-[#131C31] to-[#1E1B4B] border border-slate-800 ${className}`}
        role="img"
        aria-label={alt}
      >
        <div className="w-12 h-12 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-sky-400 mb-3">
          <Layers className="w-6 h-6" />
        </div>
        <p className="text-sm font-semibold text-white font-display">{fallbackTitle}</p>
        <p className="text-xs text-slate-400 mt-1">{fallbackSubtitle}</p>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={className}
    />
  );
};
