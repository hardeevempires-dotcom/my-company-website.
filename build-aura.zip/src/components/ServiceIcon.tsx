import React from 'react';
import {
  Globe,
  ShoppingBag,
  Smartphone,
  Code2,
  Layers,
  Cpu,
  Workflow,
  Layout,
  Database,
  Network,
  Cloud,
  Gauge,
} from 'lucide-react';

interface ServiceIconProps {
  name: string;
  className?: string;
}

export const ServiceIcon: React.FC<ServiceIconProps> = ({ name, className = 'w-5 h-5' }) => {
  switch (name) {
    case 'Globe':
      return <Globe className={className} />;
    case 'ShoppingBag':
      return <ShoppingBag className={className} />;
    case 'Smartphone':
      return <Smartphone className={className} />;
    case 'Code2':
      return <Code2 className={className} />;
    case 'Layers':
      return <Layers className={className} />;
    case 'Cpu':
      return <Cpu className={className} />;
    case 'Workflow':
      return <Workflow className={className} />;
    case 'Layout':
      return <Layout className={className} />;
    case 'Database':
      return <Database className={className} />;
    case 'Network':
      return <Network className={className} />;
    case 'Cloud':
      return <Cloud className={className} />;
    case 'Gauge':
      return <Gauge className={className} />;
    default:
      return <Layers className={className} />;
  }
};
