import { SERVICES_CATALOG, PORTFOLIO_PROJECTS, DEVELOPMENT_PROCESS } from '../data/catalog';

export interface EnquiryPayload {
  fullName: string;
  email: string;
  phone: string;
  serviceRequired: string;
  projectDescription: string;
  estimatedBudgetRM: string;
  preferredTimeline: string;
  websiteHoneypot?: string;
}

export function validateEnquiryPayload(payload: EnquiryPayload): {
  valid: boolean;
  errors: Record<string, string>;
} {
  const errors: Record<string, string> = {};

  if (payload.websiteHoneypot && payload.websiteHoneypot.trim().length > 0) {
    errors.honeypot = 'Spam check triggered.';
  }
  if (!payload.fullName || payload.fullName.trim().length < 2) {
    errors.fullName = 'Full name is required.';
  }
  if (!payload.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(payload.email.trim())) {
    errors.email = 'Valid email is required.';
  }
  if (!payload.phone || !/^[+\d\s()-]{7,24}$/.test(payload.phone.trim())) {
    errors.phone = 'Valid phone or WhatsApp number is required.';
  }
  if (!payload.serviceRequired) {
    errors.serviceRequired = 'Service selection is required.';
  }
  if (!payload.projectDescription || payload.projectDescription.trim().length < 20) {
    errors.projectDescription = 'Project description must be at least 20 characters.';
  }
  if (!payload.estimatedBudgetRM) {
    errors.estimatedBudgetRM = 'Estimated budget in RM is required.';
  }
  if (!payload.preferredTimeline) {
    errors.preferredTimeline = 'Preferred timeline is required.';
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors,
  };
}

export function runCatalogAndValidationChecks(): boolean {
  if (SERVICES_CATALOG.length !== 12) {
    throw new Error(`Expected 12 services, found ${SERVICES_CATALOG.length}`);
  }
  const hasServiceFlow = PORTFOLIO_PROJECTS.some((p) => p.slug === 'serviceflow');
  if (!hasServiceFlow) {
    throw new Error('Expected flagship ServiceFlow project in portfolio catalog');
  }
  if (DEVELOPMENT_PROCESS.length !== 7) {
    throw new Error(`Expected 7 process phases, found ${DEVELOPMENT_PROCESS.length}`);
  }
  const validCheck = validateEnquiryPayload({
    fullName: 'Ahmad Faiz',
    email: 'faiz@example.com',
    phone: '+60 12-345 6789',
    serviceRequired: 'Business Management Systems',
    projectDescription: 'We need a custom field service dispatch and quotation portal in RM.',
    estimatedBudgetRM: 'RM 35,000 – RM 75,000',
    preferredTimeline: '2 – 4 Months',
  });
  if (!validCheck.valid) {
    throw new Error('Expected valid enquiry payload to pass validation');
  }
  return true;
}
