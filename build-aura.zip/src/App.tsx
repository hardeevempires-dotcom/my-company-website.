import { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, useLocation, Navigate } from 'react-router-dom';
import type { ProjectItem, ServiceItem, SiteSettings } from './types';
import {
  SERVICES_CATALOG,
  PORTFOLIO_PROJECTS,
  DEFAULT_SITE_SETTINGS,
} from './data/catalog';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { ScrollToTop } from './components/ScrollToTop';
import { HomePage } from './pages/HomePage';
import { ServicesPage } from './pages/ServicesPage';
import { PortfolioPage } from './pages/PortfolioPage';
import { ProjectDetailPage } from './pages/ProjectDetailPage';
import { ProcessPage } from './pages/ProcessPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { PortalPage } from './pages/PortalPage';
import { LegalPage } from './pages/LegalPage';

function AppLayout({
  services,
  projects,
  settings,
}: {
  services: ServiceItem[];
  projects: ProjectItem[];
  settings: SiteSettings;
}) {
  const location = useLocation();

  // Dynamically update document title based on real URL route
  useEffect(() => {
    const path = location.pathname;
    if (path === '/') {
      document.title = 'BUILD AURA — Build Beyond Expectations | Custom Software & AI Engineering';
    } else if (path === '/services') {
      document.title = 'Our Services — Web, Mobile, Custom Software & AI | BUILD AURA';
    } else if (path === '/portfolio') {
      document.title = 'Portfolio & Projects — Featuring ServiceFlow | BUILD AURA';
    } else if (path.startsWith('/portfolio/')) {
      const slug = path.replace('/portfolio/', '');
      const project = projects.find((p) => p.slug === slug);
      document.title = `${project?.title || 'Project Case Study'} | BUILD AURA Portfolio`;
    } else if (path === '/process') {
      document.title = 'Our 7-Stage Software Development Process | BUILD AURA';
    } else if (path === '/about') {
      document.title = 'About Us — Mission, Philosophy & Core Values | BUILD AURA';
    } else if (path === '/contact') {
      document.title = 'Start a Project & Request a Quote in RM | BUILD AURA';
    } else if (path === '/portal') {
      document.title = 'Client Enquiry & Quotation Status Tracker | BUILD AURA';
    } else if (path === '/privacy') {
      document.title = 'Privacy Policy | BUILD AURA';
    } else if (path === '/terms') {
      document.title = 'Terms of Service | BUILD AURA';
    } else {
      document.title = 'BUILD AURA — Build Beyond Expectations';
    }
  }, [location.pathname, projects]);

  return (
    <div className="min-h-screen flex flex-col bg-[#060913] text-slate-100">
      <ScrollToTop />
      <Navbar />

      <main className="flex-1">
        <Routes>
          <Route path="/" element={<HomePage services={services} projects={projects} />} />
          <Route path="/services" element={<ServicesPage services={services} />} />
          <Route path="/portfolio" element={<PortfolioPage projects={projects} />} />
          <Route path="/portfolio/:slug" element={<ProjectDetailPage allProjects={projects} />} />
          <Route path="/process" element={<ProcessPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage services={services} settings={settings} />} />
          <Route path="/portal" element={<PortalPage />} />
          <Route path="/privacy" element={<LegalPage mode="privacy" settings={settings} />} />
          <Route path="/terms" element={<LegalPage mode="terms" settings={settings} />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>

      <Footer settings={settings} />
    </div>
  );
}

export function App() {
  const [services, setServices] = useState<ServiceItem[]>(SERVICES_CATALOG);
  const [projects, setProjects] = useState<ProjectItem[]>(PORTFOLIO_PROJECTS);
  const [settings, setSettings] = useState<SiteSettings>(DEFAULT_SITE_SETTINGS);

  // Fetch live persisted catalog and settings from backend
  useEffect(() => {
    fetch('/api/bootstrap')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data) {
          if (Array.isArray(data.services) && data.services.length > 0) {
            setServices(data.services);
          }
          if (Array.isArray(data.projects) && data.projects.length > 0) {
            setProjects(data.projects);
          }
          if (data.settings) {
            setSettings(data.settings);
          }
        }
      })
      .catch(() => {
        // Fallback to local static catalog if offline
      });
  }, []);

  return (
    <BrowserRouter>
      <AppLayout
        services={services}
        projects={projects}
        settings={settings}
      />
    </BrowserRouter>
  );
}

export default App;
